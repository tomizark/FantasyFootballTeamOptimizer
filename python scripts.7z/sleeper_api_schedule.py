import requests
import argparse
import os
from bs4 import BeautifulSoup
import pandas as pd

def fetch_game_data(year):
    # Base URL for game data
    url = f"https://www.footballdb.com/games/index.html?lg=NFL&yr={year}"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        print(f"Failed to fetch data from {url}")
        return None

    soup = BeautifulSoup(response.text, 'html.parser')

    # Try locating the game data table by specific class first
    tables = soup.find_all('table', class_='statistics scrollable')
    
    # Fallback: Search all tables if the specified class is not found
    if not tables:
        tables = soup.find_all('table')

    # Define headers based on game information available
    custom_headers = ['Date', 'Visitor', 'Visitor Score', 'Home', 'Home Score', 'Location']
    
    data = []
    for table in tables:
        headers = [th.text.strip() for th in table.find_all('th')]
        
        # Check if the table has relevant headers to confirm it's the correct one
        if "Visitor" in headers and "Home" in headers:
            rows = table.find_all('tr')[1:]  # Skip header row
            for row in rows:
                cols = [col.text.strip() for col in row.find_all('td')]
                if len(cols) >= 5:  # Ensure row has at least 6 columns of data
                    data.append([
                        cols[0],  # Date
                        cols[1],  # Visitor team
                        cols[2],  # Visitor score
                        cols[3],  # Home team
                        cols[4],  # Home score
                        cols[5] if len(cols) > 5 else "N/A"  # Location if available
                    ])

    # Check if any data was found
    if not data:
        print("No valid game data found after searching tables.")
        return None

    # Convert to DataFrame
    df = pd.DataFrame(data, columns=custom_headers)

    # Define the path for saving the CSV file
    folder_path = r'C:\Program Files\sleeper_env\Scripts\History'
    csv_filename = f'game_schedule_{year}.csv'
    file_path = os.path.join(folder_path, csv_filename)
    
    # Ensure the folder exists
    os.makedirs(folder_path, exist_ok=True)

    # Check if the file exists and delete if necessary
    if os.path.exists(file_path):
        os.remove(file_path)
        print(f"File {file_path} has been deleted.")

    # Save DataFrame to CSV
    df.to_csv(file_path, index=False)
    print(f"Data saved to {file_path}")

    folder_path = r'C:\Program Files\sleeper_env\Scripts'
    csv_filename = f'game_schedule_{year}.csv'
    file_path = os.path.join(folder_path, csv_filename)
    
    # Ensure the folder exists
    os.makedirs(folder_path, exist_ok=True)

    # Check if the file exists and delete if necessary
    if os.path.exists(file_path):
        os.remove(file_path)
        print(f"File {file_path} has been deleted.")

    # Save DataFrame to CSV
    df.to_csv(file_path, index=False)
    print(f"Data saved to {file_path}")

# Add argparse to handle command line arguments
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fetch game data based on the given year")
    parser.add_argument('year', type=int, help='The year (e.g., 2024)')

    args = parser.parse_args()

    # Call the function with the year argument passed from the command line
    fetch_game_data(args.year)
