import requests
import argparse
import os
from bs4 import BeautifulSoup
import pandas as pd

def fetch_fantasy_data(position, year, week, scoring_system):
    url = f"https://www.footballdb.com/fantasy-football/index.html?pos={position}&yr={year}&wk={week}&key=b6406b7aea3872d5bb677f064673c57f"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        print(f"Failed to fetch data from {url}")
        return None

    soup = BeautifulSoup(response.text, 'html.parser')

    # Find the table of statistics
    table = soup.find('table', {'class': 'statistics'})
    
    if not table:
        print("No data table found.")
        return None

    # Extract headers (skipping first 3 and removing undesired headers like "Passing", "Rushing", etc.)
    original_headers = [th.text.strip() for th in table.find_all('th')]
    
    # Customize the headers as per your requirement
    custom_headers = [
        'Player', 'Game', 'Pts*', 'Att', 'Cmp', 'Yds', 'TD', 'Int', '2Pt',
        'Att', 'Yds', 'TD', '2Pt', 'Rec', 'Yds', 'TD', '2Pt', 'FL', 'TD', 'Bolded Game Info'
    ]

    # Extract data rows
    data = []
    for row in table.find_all('tr')[1:]:  # Skip the header row
        cols = [col.text.strip() for col in row.find_all('td')]
        
        # Check if there are enough columns (at least 2 for "Game" column)
        if len(cols) >= 2:
            game_column = row.find_all('td')[1]  # "Game" is assumed to be the second column (index 1)
            
            # Extract the bolded text (if any)
            bolded_text = game_column.find('b').text.strip() if game_column.find('b') else ''
        else:
            bolded_text = ''  # No bolded text if not enough columns
        
        # Ensure each row has the same number of columns as the headers
        if len(cols) < len(custom_headers) - 1:  # Exclude the new "Bolded Game Info" column
            cols.extend([''] * (len(custom_headers) - 1 - len(cols)))  # Fill missing columns with empty strings
        
        cols.append(bolded_text)  # Add the bolded text to the new column
        data.append(cols)

    # Convert to DataFrame
    df = pd.DataFrame(data, columns=custom_headers)

    # Save to CSV
    file_path = r'C:\Program Files\sleeper_env\Scripts\History'
    csv_filename = f'fantasy_stats_{position}_{year}_week_{week}_{scoring_system}.csv'
    file_path = os.path.join(file_path, csv_filename)
    if os.path.exists(file_path):
        os.remove(file_path)  # Deletes the file
        print(f"File {file_path} has been deleted.")
    else:
        print(f"File {file_path} not found.")
	
    df.to_csv(file_path, index=False)
    print(f"Data saved to {file_path}")

    file_path = r'C:\Program Files\sleeper_env\Scripts'
    csv_filename = f'fantasy_stats_{position}_{year}_{scoring_system}.csv'
    file_path = os.path.join(file_path, csv_filename)	
    if os.path.exists(file_path):
        os.remove(file_path)  # Deletes the file
        print(f"File {file_path} has been deleted.")
    else:
        print(f"File {file_path} not found.")

    df.to_csv(file_path, index=False)
    print(f"Data saved to {file_path}")

# Add argparse to handle command line arguments
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fetch fantasy data based on the given parameters")
    parser.add_argument('position', type=str, help='The position of the player (e.g., RB, QB, TE, WR, etc.)')
    parser.add_argument('year', type=int, help='The year (e.g., 2024)')
    parser.add_argument('week', type=int, help='The week (e.g., 1, 2, 3, etc.)')
    parser.add_argument('scoring_system', type=str, help='The scoring system (e.g., PPR, Standard)')

    args = parser.parse_args()

    # Call the function with the arguments passed from the command line
    fetch_fantasy_data(args.position, args.year, args.week, args.scoring_system)
	
# Fetch and save fantasy football data
#fetch_fantasy_data('TE', 2024, 4, 'PPR')
#fetch_fantasy_data('QB', 2024, 4, 'PPR')
#fetch_fantasy_data('WR', 2024, 4, 'PPR')
#fetch_fantasy_data('RB', 2024, 4, 'PPR')
