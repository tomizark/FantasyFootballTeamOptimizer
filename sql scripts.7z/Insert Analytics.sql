drop procedure if exists p_remove_double_rows;
CREATE PROCEDURE p_remove_double_rows
AS
BEGIN
    SET NOCOUNT ON;
	delete from analytics_area_remove_double_rows;
	insert into analytics_area_remove_double_rows
	select 'WITH CTE AS (
    SELECT 
        *, 
        ROW_NUMBER() OVER (PARTITION BY '+columns+' ORDER BY (select null)) AS RowNum
    FROM '+TABLE_NAME+'
	)
	DELETE FROM CTE
	WHERE RowNum > 1;' sql_exec
	from 
	(
	select table_name, string_agg('['+column_name+']',',') columns
	FROM INFORMATION_SCHEMA.COLUMNS
	group by table_name
	) a;
	
    -- Declare variables for iteration and storing the SQL query
    DECLARE @SQLQuery NVARCHAR(MAX);

    -- Cursor to iterate over each SQL statement in the table
    DECLARE SQLCursor CURSOR FOR
    SELECT sql_exec
    FROM analytics_area_remove_double_rows;

    -- Open the cursor
    OPEN SQLCursor;

    -- Fetch the first row
    FETCH NEXT FROM SQLCursor INTO @SQLQuery;

    -- Iterate through the cursor
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Execute the SQL query
            EXEC(@SQLQuery);
        END TRY
        BEGIN CATCH
            -- Handle errors if any SQL fails
            PRINT 'Error occurred while executing: ' + @SQLQuery;
            PRINT ERROR_MESSAGE();
        END CATCH;

        -- Fetch the next row
        FETCH NEXT FROM SQLCursor INTO @SQLQuery;
    END;

    -- Close and deallocate the cursor
    CLOSE SQLCursor;
    DEALLOCATE SQLCursor;
END;


drop procedure if exists p_insert_analitics_by_cur_week_for_futu;
create procedure p_insert_analitics_by_cur_week_for_futu (@p_week int) as
begin
delete from analytics_area_all_positions_prev_pct where week = @p_week;
insert into analytics_area_all_positions_prev_pct
select DISTINCT
pct.id_player,
pct.player,
pct.position,
pool_area_all_positions_by_week.team,
pct.week,
pct.pct,
pct.PassAtt_pct,
pct.PassCmp_pct,
pct.PassYds_pct,
pct.PassTD_pct,
pct.PassInt_pct,
pct.Pass2Pt_pct,
pct.RushAtt_pct,
pct.RushYds_pct,
pct.RushTD_pct,
pct.Rush2Pt_pct,
pct.RecRec_pct,
pct.RecYds_pct,
pct.RecTD_pct,
pct.Rec2Pt_pct,
pct.FumFL_pct,
pct.FumTD_pct,
pct.XPA_pct,
pct.XPM_pct,
pct.FGA_pct,
pct.FGM_pct,
pct.[pts_50+_pct],
pct.Sack_pct,
pct.Int_pct,
pct.Saf_pct,
pct.FR_pct,
pct.Blk_pct,
pct.TD_pct,
pct.PA_pct,
pct.PassYdsDST_pct,
pct.RushYdsDST_pct,
pct.TotYdsDST_pct
from
(select id_player,team from pool_area_all_positions_by_week where week = @p_week) pool_area_all_positions_by_week join
(select 
pool_area_all_positions_by_week.id_player,
pool_area_all_positions_by_week.player,
pool_area_all_positions_by_week.position,
@p_week week,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.pts),0) = 0 then cast(0 as numeric(3,2)) else cast(sum(pool_area_all_positions_by_week.pts)/sum(pool_area_all_positions_by_week_sum_by_opp.pts) as numeric(3,2)) end pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.PassAtt),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.PassAtt) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.PassAtt) as numeric)as numeric(3,2)) end PassAtt_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.PassCmp),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.PassCmp) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.PassCmp) as numeric)as numeric(3,2)) end PassCmp_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.PassYds),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.PassYds) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.PassYds) as numeric)as numeric(3,2)) end PassYds_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.PassTD),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.PassTD) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.PassTD) as numeric)as numeric(3,2)) end PassTD_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.PassInt),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.PassInt) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.PassInt) as numeric)as numeric(3,2)) end PassInt_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.Pass2Pt),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.Pass2Pt) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.Pass2Pt) as numeric)as numeric(3,2)) end Pass2Pt_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.RushAtt),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.RushAtt) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.RushAtt) as numeric)as numeric(3,2)) end RushAtt_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.RushYds),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.RushYds) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.RushYds) as numeric)as numeric(3,2)) end RushYds_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.RushTD),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.RushTD) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.RushTD) as numeric)as numeric(3,2)) end RushTD_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.Rush2Pt),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.Rush2Pt) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.Rush2Pt) as numeric)as numeric(3,2)) end Rush2Pt_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.RecRec),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.RecRec) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.RecRec) as numeric)as numeric(3,2)) end RecRec_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.RecYds),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.RecYds) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.RecYds) as numeric)as numeric(3,2)) end RecYds_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.RecTD),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.RecTD) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.RecTD) as numeric)as numeric(3,2)) end RecTD_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.Rec2Pt),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.Rec2Pt) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.Rec2Pt) as numeric)as numeric(3,2)) end Rec2Pt_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.FumFL),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.FumFL) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.FumFL) as numeric)as numeric(3,2)) end FumFL_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.FumTD),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.FumTD) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.FumTD) as numeric)as numeric(3,2)) end FumTD_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.XPA),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.XPA) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.XPA) as numeric)as numeric(3,2)) end XPA_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.XPM),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.XPM) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.XPM) as numeric)as numeric(3,2)) end XPM_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.FGA),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.FGA) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.FGA) as numeric)as numeric(3,2)) end FGA_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.FGM),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.FGM) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.FGM) as numeric)as numeric(3,2)) end FGM_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.[50+]),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.[50+]) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.[50+]) as numeric)as numeric(3,2)) end [pts_50+_pct],
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.Sack),0) = 0 then cast(0 as numeric(3,2)) else cast(sum(pool_area_all_positions_by_week.Sack)/sum(pool_area_all_positions_by_week_sum_by_opp.Sack) as numeric(3,2)) end Sack_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.Int),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.Int) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.Int) as numeric)as numeric(3,2)) end Int_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.Saf),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.Saf) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.Saf) as numeric)as numeric(3,2)) end Saf_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.FR),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.FR) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.FR) as numeric)as numeric(3,2)) end FR_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.Blk),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.Blk) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.Blk) as numeric)as numeric(3,2)) end Blk_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.TD),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.TD) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.TD) as numeric)as numeric(3,2)) end TD_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.PA),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.PA) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.PA) as numeric)as numeric(3,2)) end PA_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.PassYdsDST),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.PassYdsDST) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.PassYdsDST) as numeric)as numeric(3,2)) end PassYdsDST_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.RushYdsDST),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.RushYdsDST) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.RushYdsDST) as numeric)as numeric(3,2)) end RushYdsDST_pct,
case when isnull(sum(pool_area_all_positions_by_week_sum_by_opp.TotYdsDST),0) = 0 then cast(0 as numeric(3,2)) else cast(cast(sum(pool_area_all_positions_by_week.TotYdsDST) as numeric)/cast(sum(pool_area_all_positions_by_week_sum_by_opp.TotYdsDST) as numeric)as numeric(3,2)) end TotYdsDST_pct
from (select * from pool_area_all_positions_by_week_sum_by_opp where week <= @p_week) pool_area_all_positions_by_week_sum_by_opp join (select * from pool_area_all_positions_by_week where week <= @p_week) pool_area_all_positions_by_week
on pool_area_all_positions_by_week_sum_by_opp.week = pool_area_all_positions_by_week.week and 
pool_area_all_positions_by_week_sum_by_opp.team = pool_area_all_positions_by_week.team and 
pool_area_all_positions_by_week_sum_by_opp.opponent = pool_area_all_positions_by_week.opponent and 
pool_area_all_positions_by_week_sum_by_opp.position = pool_area_all_positions_by_week.position
group by pool_area_all_positions_by_week.id_player,pool_area_all_positions_by_week.player,pool_area_all_positions_by_week.position
) pct on (pct.id_player = pool_area_all_positions_by_week.id_player);

delete from analytics_area_all_positions_prev_pct_median where week = @p_week;
insert into analytics_area_all_positions_prev_pct_median
select distinct
id_player,player,position, week,median_pts_pct,median_PassAtt_pct,median_PassCmp_pct,median_PassYds_pct,median_PassTD_pct,median_PassInt_pct,median_Pass2Pt_pct,median_RushAtt_pct,median_RushYds_pct,median_RushTD_pct,median_Rush2Pt_pct,median_RecRec_pct,median_RecYds_pct,median_RecTD_pct,median_Rec2Pt_pct,median_FumFL_pct,median_FumTD_pct,median_XPA_pct,median_XPM_pct,median_FGA_pct,median_FGM_pct,[median_50+_pct],median_Sack_pct,median_Int_pct,median_Saf_pct,median_FR_pct,median_Blk_pct,median_TD_pct,median_PA_pct,median_PassYdsDST_pct,median_RushYdsDST_pct,median_TotYdsDST_pct
from 
(
select id_player,player,position,@p_week week,
pts_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY pts_pct) over (partition by id_player,player) as median_pts_pct,
PassAtt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassAtt_pct) over (partition by id_player,player) as median_PassAtt_pct,
PassCmp_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassCmp_pct) over (partition by id_player,player) as median_PassCmp_pct,
PassYds_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYds_pct) over (partition by id_player,player) as median_PassYds_pct,
PassTD_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassTD_pct) over (partition by id_player,player) as median_PassTD_pct,
PassInt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassInt_pct) over (partition by id_player,player) as median_PassInt_pct,
Pass2Pt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Pass2Pt_pct) over (partition by id_player,player) as median_Pass2Pt_pct,
RushAtt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushAtt_pct) over (partition by id_player,player) as median_RushAtt_pct,
RushYds_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYds_pct) over (partition by id_player,player) as median_RushYds_pct,
RushTD_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushTD_pct) over (partition by id_player,player) as median_RushTD_pct,
Rush2Pt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rush2Pt_pct) over (partition by id_player,player) as median_Rush2Pt_pct,
RecRec_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecRec_pct) over (partition by id_player,player) as median_RecRec_pct,
RecYds_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecYds_pct) over (partition by id_player,player) as median_RecYds_pct,
RecTD_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecTD_pct) over (partition by id_player,player) as median_RecTD_pct,
Rec2Pt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rec2Pt_pct) over (partition by id_player,player) as median_Rec2Pt_pct,
FumFL_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumFL_pct) over (partition by id_player,player) as median_FumFL_pct,
FumTD_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumTD_pct) over (partition by id_player,player) as median_FumTD_pct,
XPA_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPA_pct) over (partition by id_player,player) as median_XPA_pct,
XPM_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPM_pct) over (partition by id_player,player) as median_XPM_pct,
FGA_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGA_pct) over (partition by id_player,player) as median_FGA_pct,
FGM_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGM_pct) over (partition by id_player,player) as median_FGM_pct,
[50+_pct], PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY [50+_pct]) over (partition by id_player,player) as [median_50+_pct],
Sack_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Sack_pct) over (partition by id_player,player) as median_Sack_pct,
Int_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Int_pct) over (partition by id_player,player) as median_Int_pct,
Saf_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Saf_pct) over (partition by id_player,player) as median_Saf_pct,
FR_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FR_pct) over (partition by id_player,player) as median_FR_pct,
Blk_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Blk_pct) over (partition by id_player,player) as median_Blk_pct,
TD_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TD_pct) over (partition by id_player,player) as median_TD_pct,
PA_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PA_pct) over (partition by id_player,player) as median_PA_pct,
PassYdsDST_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYdsDST_pct) over (partition by id_player,player) as median_PassYdsDST_pct,
RushYdsDST_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYdsDST_pct) over (partition by id_player,player) as median_RushYdsDST_pct,
TotYdsDST_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TotYdsDST_pct) over (partition by id_player,player) as median_TotYdsDST_pct
from analytics_area_all_positions_prev_pct where week <= @p_week
group by id_player,player,position,pts_pct,PassAtt_pct,PassCmp_pct,PassYds_pct,PassTD_pct,PassInt_pct,Pass2Pt_pct,RushAtt_pct,RushYds_pct,RushTD_pct,Rush2Pt_pct,RecRec_pct,RecYds_pct,RecTD_pct,Rec2Pt_pct,FumFL_pct,FumTD_pct,XPA_pct,XPM_pct,FGA_pct,FGM_pct,[50+_pct],Sack_pct,Int_pct,Saf_pct,FR_pct,Blk_pct,TD_pct,PA_pct,PassYdsDST_pct,RushYdsDST_pct,TotYdsDST_pct
) a;

delete from analytics_area_all_positions_prev_pct_median_last_3_week where week = @p_week;
insert into analytics_area_all_positions_prev_pct_median_last_3_week
select distinct
id_player,player,position, week,median_pts_pct,median_PassAtt_pct,median_PassCmp_pct,median_PassYds_pct,median_PassTD_pct,median_PassInt_pct,median_Pass2Pt_pct,median_RushAtt_pct,median_RushYds_pct,median_RushTD_pct,median_Rush2Pt_pct,median_RecRec_pct,median_RecYds_pct,median_RecTD_pct,median_Rec2Pt_pct,median_FumFL_pct,median_FumTD_pct,median_XPA_pct,median_XPM_pct,median_FGA_pct,median_FGM_pct,[median_50+_pct],median_Sack_pct,median_Int_pct,median_Saf_pct,median_FR_pct,median_Blk_pct,median_TD_pct,median_PA_pct,median_PassYdsDST_pct,median_RushYdsDST_pct,median_TotYdsDST_pct
from 
(
select id_player,player,position,@p_week week,
pts_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY pts_pct) over (partition by id_player,player) as median_pts_pct,
PassAtt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassAtt_pct) over (partition by id_player,player) as median_PassAtt_pct,
PassCmp_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassCmp_pct) over (partition by id_player,player) as median_PassCmp_pct,
PassYds_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYds_pct) over (partition by id_player,player) as median_PassYds_pct,
PassTD_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassTD_pct) over (partition by id_player,player) as median_PassTD_pct,
PassInt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassInt_pct) over (partition by id_player,player) as median_PassInt_pct,
Pass2Pt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Pass2Pt_pct) over (partition by id_player,player) as median_Pass2Pt_pct,
RushAtt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushAtt_pct) over (partition by id_player,player) as median_RushAtt_pct,
RushYds_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYds_pct) over (partition by id_player,player) as median_RushYds_pct,
RushTD_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushTD_pct) over (partition by id_player,player) as median_RushTD_pct,
Rush2Pt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rush2Pt_pct) over (partition by id_player,player) as median_Rush2Pt_pct,
RecRec_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecRec_pct) over (partition by id_player,player) as median_RecRec_pct,
RecYds_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecYds_pct) over (partition by id_player,player) as median_RecYds_pct,
RecTD_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecTD_pct) over (partition by id_player,player) as median_RecTD_pct,
Rec2Pt_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rec2Pt_pct) over (partition by id_player,player) as median_Rec2Pt_pct,
FumFL_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumFL_pct) over (partition by id_player,player) as median_FumFL_pct,
FumTD_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumTD_pct) over (partition by id_player,player) as median_FumTD_pct,
XPA_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPA_pct) over (partition by id_player,player) as median_XPA_pct,
XPM_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPM_pct) over (partition by id_player,player) as median_XPM_pct,
FGA_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGA_pct) over (partition by id_player,player) as median_FGA_pct,
FGM_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGM_pct) over (partition by id_player,player) as median_FGM_pct,
[50+_pct], PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY [50+_pct]) over (partition by id_player,player) as [median_50+_pct],
Sack_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Sack_pct) over (partition by id_player,player) as median_Sack_pct,
Int_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Int_pct) over (partition by id_player,player) as median_Int_pct,
Saf_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Saf_pct) over (partition by id_player,player) as median_Saf_pct,
FR_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FR_pct) over (partition by id_player,player) as median_FR_pct,
Blk_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Blk_pct) over (partition by id_player,player) as median_Blk_pct,
TD_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TD_pct) over (partition by id_player,player) as median_TD_pct,
PA_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PA_pct) over (partition by id_player,player) as median_PA_pct,
PassYdsDST_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYdsDST_pct) over (partition by id_player,player) as median_PassYdsDST_pct,
RushYdsDST_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYdsDST_pct) over (partition by id_player,player) as median_RushYdsDST_pct,
TotYdsDST_pct, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TotYdsDST_pct) over (partition by id_player,player) as median_TotYdsDST_pct
from 
(
select analytics_area_all_positions_prev_pct.*,
pool_area_all_positions_last_3_week.week_prev_3 
from analytics_area_all_positions_prev_pct 
join pool_area_all_positions_last_3_week 
on 
(
analytics_area_all_positions_prev_pct.id_player = pool_area_all_positions_last_3_week.id_player and
@p_week = pool_area_all_positions_last_3_week.week
)
)
analytics_area_all_positions_prev_pct where week >= week_prev_3 and week <= @p_week
group by id_player,player,position,pts_pct,PassAtt_pct,PassCmp_pct,PassYds_pct,PassTD_pct,PassInt_pct,Pass2Pt_pct,RushAtt_pct,RushYds_pct,RushTD_pct,Rush2Pt_pct,RecRec_pct,RecYds_pct,RecTD_pct,Rec2Pt_pct,FumFL_pct,FumTD_pct,XPA_pct,XPM_pct,FGA_pct,FGM_pct,[50+_pct],Sack_pct,Int_pct,Saf_pct,FR_pct,Blk_pct,TD_pct,PA_pct,PassYdsDST_pct,RushYdsDST_pct,TotYdsDST_pct
) a;

delete from analytics_area_all_positions_prev_median where week = @p_week;
insert into analytics_area_all_positions_prev_median
select distinct a.id_player,player,position,pool_area_all_positions_by_week.team,@p_week week, median_pts, median_PassAtt,median_PassCmp,median_PassYds,median_PassTD,median_PassInt,median_Pass2Pt,median_RushAtt,median_RushYds,median_RushTD,median_Rush2Pt,median_RecRec,median_RecYds,median_RecTD,median_Rec2Pt,median_FumFL,median_FumTD,median_XPA,median_XPM,median_FGA,median_FGM,[median_50+],median_Sack,median_Int,median_Saf,median_FR,median_Blk,median_TD,median_PA,median_PassYdsDST,median_RushYdsDST,median_TotYdsDST
from
(select id_player,team from pool_area_all_positions_by_week where week = @p_week) pool_area_all_positions_by_week join
(
select id_player,player,position,
pts, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY pts) over (partition by id_player,player,position) as median_pts,
PassAtt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassAtt) over (partition by id_player,player,position) as median_PassAtt,
PassCmp, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassCmp) over (partition by id_player,player,position) as median_PassCmp,
PassYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYds) over (partition by id_player,player,position) as median_PassYds,
PassTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassTD) over (partition by id_player,player,position) as median_PassTD,
PassInt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassInt) over (partition by id_player,player,position) as median_PassInt,
Pass2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Pass2Pt) over (partition by id_player,player,position) as median_Pass2Pt,
RushAtt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushAtt) over (partition by id_player,player,position) as median_RushAtt,
RushYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYds) over (partition by id_player,player,position) as median_RushYds,
RushTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushTD) over (partition by id_player,player,position) as median_RushTD,
Rush2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rush2Pt) over (partition by id_player,player,position) as median_Rush2Pt,
RecRec, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecRec) over (partition by id_player,player,position) as median_RecRec,
RecYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecYds) over (partition by id_player,player,position) as median_RecYds,
RecTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecTD) over (partition by id_player,player,position) as median_RecTD,
Rec2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rec2Pt) over (partition by id_player,player,position) as median_Rec2Pt,
FumFL, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumFL) over (partition by id_player,player,position) as median_FumFL,
FumTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumTD) over (partition by id_player,player,position) as median_FumTD,
XPA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPA) over (partition by id_player,player,position) as median_XPA,
XPM, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPM) over (partition by id_player,player,position) as median_XPM,
FGA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGA) over (partition by id_player,player,position) as median_FGA,
FGM, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGM) over (partition by id_player,player,position) as median_FGM,
[50+], PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY [50+]) over (partition by id_player,player,position) as [median_50+],
Sack, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Sack) over (partition by id_player,player,position) as median_Sack,
Int, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Int) over (partition by id_player,player,position) as median_Int,
Saf, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Saf) over (partition by id_player,player,position) as median_Saf,
FR, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FR) over (partition by id_player,player,position) as median_FR,
Blk, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Blk) over (partition by id_player,player,position) as median_Blk,
TD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TD) over (partition by id_player,player,position) as median_TD,
PA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PA) over (partition by id_player,player,position) as median_PA,
PassYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYdsDST) over (partition by id_player,player,position) as median_PassYdsDST,
RushYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYdsDST) over (partition by id_player,player,position) as median_RushYdsDST,
TotYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TotYdsDST) over (partition by id_player,player,position) as median_TotYdsDST
from pool_area_all_positions_by_week where week <= @p_week group by id_player,player,position,pts,PassAtt,PassCmp,PassYds,PassTD,PassInt,Pass2Pt,RushAtt,RushYds,RushTD,Rush2Pt,RecRec,RecYds,RecTD,Rec2Pt,FumFL,FumTD,XPA,XPM,FGA,FGM,[50+],Sack,Int,Saf,FR,Blk,TD,PA,PassYdsDST,RushYdsDST,TotYdsDST
) a on (a.id_player = pool_area_all_positions_by_week.id_player);

delete from analytics_area_all_positions_prev_median_last_3_week where week = @p_week;
insert into analytics_area_all_positions_prev_median_last_3_week
select distinct a.id_player,a.player,a.position,pool_area_all_positions_by_week.team,@p_week week, median_pts, median_PassAtt,median_PassCmp,median_PassYds,median_PassTD,median_PassInt,median_Pass2Pt,median_RushAtt,median_RushYds,median_RushTD,median_Rush2Pt,median_RecRec,median_RecYds,median_RecTD,median_Rec2Pt,median_FumFL,median_FumTD,median_XPA,median_XPM,median_FGA,median_FGM,[median_50+],median_Sack,median_Int,median_Saf,median_FR,median_Blk,median_TD,median_PA,median_PassYdsDST,median_RushYdsDST,median_TotYdsDST
from
(select id_player,team from pool_area_all_positions_by_week where week = @p_week) pool_area_all_positions_by_week join
(
select id_player,player,position,
pts, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY pts) over (partition by id_player,player,position) as median_pts,
PassAtt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassAtt) over (partition by id_player,player,position) as median_PassAtt,
PassCmp, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassCmp) over (partition by id_player,player,position) as median_PassCmp,
PassYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYds) over (partition by id_player,player,position) as median_PassYds,
PassTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassTD) over (partition by id_player,player,position) as median_PassTD,
PassInt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassInt) over (partition by id_player,player,position) as median_PassInt,
Pass2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Pass2Pt) over (partition by id_player,player,position) as median_Pass2Pt,
RushAtt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushAtt) over (partition by id_player,player,position) as median_RushAtt,
RushYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYds) over (partition by id_player,player,position) as median_RushYds,
RushTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushTD) over (partition by id_player,player,position) as median_RushTD,
Rush2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rush2Pt) over (partition by id_player,player,position) as median_Rush2Pt,
RecRec, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecRec) over (partition by id_player,player,position) as median_RecRec,
RecYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecYds) over (partition by id_player,player,position) as median_RecYds,
RecTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecTD) over (partition by id_player,player,position) as median_RecTD,
Rec2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rec2Pt) over (partition by id_player,player,position) as median_Rec2Pt,
FumFL, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumFL) over (partition by id_player,player,position) as median_FumFL,
FumTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumTD) over (partition by id_player,player,position) as median_FumTD,
XPA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPA) over (partition by id_player,player,position) as median_XPA,
XPM, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPM) over (partition by id_player,player,position) as median_XPM,
FGA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGA) over (partition by id_player,player,position) as median_FGA,
FGM, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGM) over (partition by id_player,player,position) as median_FGM,
[50+], PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY [50+]) over (partition by id_player,player,position) as [median_50+],
Sack, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Sack) over (partition by id_player,player,position) as median_Sack,
Int, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Int) over (partition by id_player,player,position) as median_Int,
Saf, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Saf) over (partition by id_player,player,position) as median_Saf,
FR, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FR) over (partition by id_player,player,position) as median_FR,
Blk, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Blk) over (partition by id_player,player,position) as median_Blk,
TD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TD) over (partition by id_player,player,position) as median_TD,
PA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PA) over (partition by id_player,player,position) as median_PA,
PassYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYdsDST) over (partition by id_player,player,position) as median_PassYdsDST,
RushYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYdsDST) over (partition by id_player,player,position) as median_RushYdsDST,
TotYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TotYdsDST) over (partition by id_player,player,position) as median_TotYdsDST
from 
(
select pool_area_all_positions_by_week.*,
pool_area_all_positions_last_3_week.week_prev_3 
from pool_area_all_positions_by_week 
join pool_area_all_positions_last_3_week 
on 
(
pool_area_all_positions_by_week.id_player = pool_area_all_positions_last_3_week.id_player and
@p_week = pool_area_all_positions_last_3_week.week
)
)
pool_area_all_positions_by_week where week >= week_prev_3 and week <= @p_week group by id_player,player,position,pts,PassAtt,PassCmp,PassYds,PassTD,PassInt,Pass2Pt,RushAtt,RushYds,RushTD,Rush2Pt,RecRec,RecYds,RecTD,Rec2Pt,FumFL,FumTD,XPA,XPM,FGA,FGM,[50+],Sack,Int,Saf,FR,Blk,TD,PA,PassYdsDST,RushYdsDST,TotYdsDST
) a on (a.id_player = pool_area_all_positions_by_week.id_player);

delete from analytics_area_all_positions_opponent_prev_median where week = @p_week;
insert into analytics_area_all_positions_opponent_prev_median
select distinct position,opponent,@p_week week, median_pts, median_PassAtt,median_PassCmp,median_PassYds,median_PassTD,median_PassInt,median_Pass2Pt,median_RushAtt,median_RushYds,median_RushTD,median_Rush2Pt,median_RecRec,median_RecYds,median_RecTD,median_Rec2Pt,median_FumFL,median_FumTD,median_XPA,median_XPM,median_FGA,median_FGM,[median_50+],median_Sack,median_Int,median_Saf,median_FR,median_Blk,median_TD,median_PA,median_PassYdsDST,median_RushYdsDST,median_TotYdsDST
from (
select position,opponent,
pts, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY pts) over (partition by position, opponent) as median_pts,
PassAtt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassAtt) over (partition by position, opponent) as median_PassAtt,
PassCmp, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassCmp) over (partition by position, opponent) as median_PassCmp,
PassYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYds) over (partition by position, opponent) as median_PassYds,
PassTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassTD) over (partition by position, opponent) as median_PassTD,
PassInt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassInt) over (partition by position, opponent) as median_PassInt,
Pass2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Pass2Pt) over (partition by position, opponent) as median_Pass2Pt,
RushAtt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushAtt) over (partition by position, opponent) as median_RushAtt,
RushYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYds) over (partition by position, opponent) as median_RushYds,
RushTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushTD) over (partition by position, opponent) as median_RushTD,
Rush2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rush2Pt) over (partition by position, opponent) as median_Rush2Pt,
RecRec, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecRec) over (partition by position, opponent) as median_RecRec,
RecYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecYds) over (partition by position, opponent) as median_RecYds,
RecTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecTD) over (partition by position, opponent) as median_RecTD,
Rec2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rec2Pt) over (partition by position, opponent) as median_Rec2Pt,
FumFL, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumFL) over (partition by position, opponent) as median_FumFL,
FumTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumTD) over (partition by position, opponent) as median_FumTD,
XPA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPA) over (partition by position, opponent) as median_XPA,
XPM, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPM) over (partition by position, opponent) as median_XPM,
FGA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGA) over (partition by position, opponent) as median_FGA,
FGM, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGM) over (partition by position, opponent) as median_FGM,
[50+], PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY [50+]) over (partition by position, opponent) as [median_50+],
Sack, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Sack) over (partition by position, opponent) as median_Sack,
Int, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Int) over (partition by position, opponent) as median_Int,
Saf, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Saf) over (partition by position, opponent) as median_Saf,
FR, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FR) over (partition by position, opponent) as median_FR,
Blk, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Blk) over (partition by position, opponent) as median_Blk,
TD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TD) over (partition by position, opponent) as median_TD,
PA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PA) over (partition by position, opponent) as median_PA,
PassYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYdsDST) over (partition by position, opponent) as median_PassYdsDST,
RushYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYdsDST) over (partition by position, opponent) as median_RushYdsDST,
TotYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TotYdsDST) over (partition by position, opponent) as median_TotYdsDST
from pool_area_all_positions_by_week_sum_by_opp where week <= @p_week 
group by position,opponent,pts,PassAtt,PassCmp,PassYds,PassTD,PassInt,Pass2Pt,RushAtt,RushYds,RushTD,Rush2Pt,RecRec,RecYds,RecTD,Rec2Pt,FumFL,FumTD,XPA,XPM,FGA,FGM,[50+],Sack,Int,Saf,FR,Blk,TD,PA,PassYdsDST,RushYdsDST,TotYdsDST
) a;

delete from analytics_area_all_positions_opponent_prev_median_last_3_week where week = @p_week;
insert into analytics_area_all_positions_opponent_prev_median_last_3_week
select distinct position,opponent,@p_week week, median_pts, median_PassAtt,median_PassCmp,median_PassYds,median_PassTD,median_PassInt,median_Pass2Pt,median_RushAtt,median_RushYds,median_RushTD,median_Rush2Pt,median_RecRec,median_RecYds,median_RecTD,median_Rec2Pt,median_FumFL,median_FumTD,median_XPA,median_XPM,median_FGA,median_FGM,[median_50+],median_Sack,median_Int,median_Saf,median_FR,median_Blk,median_TD,median_PA,median_PassYdsDST,median_RushYdsDST,median_TotYdsDST
from (
select position,opponent,
pts, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY pts) over (partition by position, opponent) as median_pts,
PassAtt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassAtt) over (partition by position, opponent) as median_PassAtt,
PassCmp, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassCmp) over (partition by position, opponent) as median_PassCmp,
PassYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYds) over (partition by position, opponent) as median_PassYds,
PassTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassTD) over (partition by position, opponent) as median_PassTD,
PassInt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassInt) over (partition by position, opponent) as median_PassInt,
Pass2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Pass2Pt) over (partition by position, opponent) as median_Pass2Pt,
RushAtt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushAtt) over (partition by position, opponent) as median_RushAtt,
RushYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYds) over (partition by position, opponent) as median_RushYds,
RushTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushTD) over (partition by position, opponent) as median_RushTD,
Rush2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rush2Pt) over (partition by position, opponent) as median_Rush2Pt,
RecRec, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecRec) over (partition by position, opponent) as median_RecRec,
RecYds, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecYds) over (partition by position, opponent) as median_RecYds,
RecTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RecTD) over (partition by position, opponent) as median_RecTD,
Rec2Pt, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Rec2Pt) over (partition by position, opponent) as median_Rec2Pt,
FumFL, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumFL) over (partition by position, opponent) as median_FumFL,
FumTD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FumTD) over (partition by position, opponent) as median_FumTD,
XPA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPA) over (partition by position, opponent) as median_XPA,
XPM, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY XPM) over (partition by position, opponent) as median_XPM,
FGA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGA) over (partition by position, opponent) as median_FGA,
FGM, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FGM) over (partition by position, opponent) as median_FGM,
[50+], PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY [50+]) over (partition by position, opponent) as [median_50+],
Sack, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Sack) over (partition by position, opponent) as median_Sack,
Int, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Int) over (partition by position, opponent) as median_Int,
Saf, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Saf) over (partition by position, opponent) as median_Saf,
FR, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY FR) over (partition by position, opponent) as median_FR,
Blk, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Blk) over (partition by position, opponent) as median_Blk,
TD, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TD) over (partition by position, opponent) as median_TD,
PA, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PA) over (partition by position, opponent) as median_PA,
PassYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY PassYdsDST) over (partition by position, opponent) as median_PassYdsDST,
RushYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY RushYdsDST) over (partition by position, opponent) as median_RushYdsDST,
TotYdsDST, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY TotYdsDST) over (partition by position, opponent) as median_TotYdsDST
from 
(
select pool_area_all_positions_by_week_sum_by_opp.*,
pool_area_all_teams_last_3_week.week_prev_3 
from 
pool_area_all_positions_by_week_sum_by_opp 
join pool_area_all_teams_last_3_week 
on 
(
pool_area_all_positions_by_week_sum_by_opp.opponent = pool_area_all_teams_last_3_week.team and
@p_week = pool_area_all_teams_last_3_week.week
)
) pool_area_all_positions_by_week_sum_by_opp where week >= week_prev_3 and week <= @p_week 
group by position,opponent,pts,PassAtt,PassCmp,PassYds,PassTD,PassInt,Pass2Pt,RushAtt,RushYds,RushTD,Rush2Pt,RecRec,RecYds,RecTD,Rec2Pt,FumFL,FumTD,XPA,XPM,FGA,FGM,[50+],Sack,Int,Saf,FR,Blk,TD,PA,PassYdsDST,RushYdsDST,TotYdsDST
) a;

delete from analytics_area_all_positions_pts_acc_to_opponent where week = @p_week+1;
insert into analytics_area_all_positions_pts_acc_to_opponent
select a.*, (median_pts+pts_calc) / 2 pts
from
(select a.*,
isnull([median_PassYds],0)*isnull(stage_area_points.[PassYds],0) +
isnull([median_PassTD],0)*isnull(stage_area_points.[PassTD],0) +
isnull([median_PassInt],0)*isnull(stage_area_points.[PassInt],0) +
isnull([median_Pass2Pt],0)*isnull(stage_area_points.[Pass2Pt],0) +   
isnull([median_RushYds],0)*isnull(stage_area_points.[RushYds],0) +   
isnull([median_RushTD],0)*isnull(stage_area_points.[RushTD],0) +   
isnull([median_Rush2Pt],0)*isnull(stage_area_points.[Rush2Pt],0) +   
isnull([median_RecRec],0)*isnull(stage_area_points.[RecRec],0) +   
isnull([median_RecYds],0)*isnull(stage_area_points.[RecYds],0) +   
isnull([median_RecTD],0)*isnull(stage_area_points.[RecTD],0) +   
isnull([median_Rec2Pt],0)*isnull(stage_area_points.[Rec2Pt],0) +   
isnull([median_FumFL],0)*isnull(stage_area_points.[FumFL],0) +   
isnull([median_FumTD],0)*isnull(stage_area_points.[FumTD],0) +   
(isnull([median_XPA],0)-isnull([median_XPM],0))*isnull(stage_area_points.[XPMissed],0) +   
isnull([median_XPM],0)*isnull(stage_area_points.[XPMade],0) +   
(isnull([median_FGA],0)-isnull([median_FGM],0))*isnull(stage_area_points.[FGMissed],0) +   
isnull([median_FGM],0)*isnull(stage_area_points.[FGMade],0) +   
isnull([median_50+],0)*isnull(stage_area_points.[50+],0) +   
isnull([median_Sack],0)*isnull(stage_area_points.[Sack],0) +   
isnull([median_Int],0)*isnull(stage_area_points.[Int],0) +   
isnull([median_Saf],0)*isnull(stage_area_points.[Saf],0) +   
isnull([median_FR],0)*isnull(stage_area_points.[FR],0) +   
isnull([median_Blk],0)*isnull(stage_area_points.[Blk],0) +   
isnull([median_TD],0)*isnull(stage_area_points.[TD],0) +   
CASE 
WHEN [median_PA] = 0 then stage_area_points.[PA 0]
WHEN [median_PA] between 1 and 6 then stage_area_points.[PA 6]
WHEN [median_PA] between 7 and 13 then stage_area_points.[PA 13]
WHEN [median_PA] between 14 and 20 then stage_area_points.[PA 20]
WHEN [median_PA] between 28 and 34 then stage_area_points.[PA 34]
WHEN [median_PA] >= 35 then stage_area_points.[PA 35]
else 0 
end +
CASE 
WHEN [median_TotYdsDST] < 100 then stage_area_points.[TotYdsDST 100]
WHEN [median_TotYdsDST] between 100 and 199 then stage_area_points.[TotYdsDST 199]
WHEN [median_TotYdsDST] between 200 and 299 then stage_area_points.[TotYdsDST 299]
WHEN [median_TotYdsDST] between 350 and 399 then stage_area_points.[TotYdsDST 399]
WHEN [median_TotYdsDST] between 400 and 449 then stage_area_points.[TotYdsDST 449]
WHEN [median_TotYdsDST] between 450 and 499 then stage_area_points.[TotYdsDST 499] 
WHEN [median_TotYdsDST] between 500 and 549 then stage_area_points.[TotYdsDST 549]
WHEN [median_TotYdsDST] >= 550 then stage_area_points.[TotYdsDST 550]
else 0
end 
pts_calc
from
(select 
analytics_area_all_positions_prev_pct_median.id_Player,
analytics_area_all_positions_prev_pct_median.player,
analytics_area_all_positions_prev_pct_median.position,
analytics_area_all_positions_prev_pct_median.week+1 week,
median_pts_pct*median_pts median_pts,
median_PassAtt_pct*median_PassAtt median_PassAtt,
median_PassCmp_pct*median_PassCmp median_PassCmp,
median_PassYds_pct*median_PassYds median_PassYds,
median_PassTD_pct*median_PassTD median_PassTD,
median_PassInt_pct*median_PassInt median_PassInt,
median_Pass2Pt_pct*median_Pass2Pt median_Pass2Pt,
median_RushAtt_pct*median_RushAtt median_RushAtt,
median_RushYds_pct*median_RushYds median_RushYds,
median_RushTD_pct*median_RushTD median_RushTD,
median_Rush2Pt_pct*median_Rush2Pt median_Rush2Pt,
median_RecRec_pct*median_RecRec median_RecRec,
median_RecYds_pct*median_RecYds median_RecYds,
median_RecTD_pct*median_RecTD median_RecTD,
median_Rec2Pt_pct*median_Rec2Pt median_Rec2Pt,
median_FumFL_pct*median_FumFL median_FumFL,
median_FumTD_pct*median_FumTD median_FumTD,
median_XPA_pct*median_XPA median_XPA,
median_XPM_pct*median_XPM median_XPM,
median_FGA_pct*median_FGA median_FGA,
median_FGM_pct*median_FGM median_FGM,
[median_50+_pct]*[median_50+] [median_50+],
median_Sack_pct*median_Sack median_Sack,
median_Int_pct*median_Int median_Int,
median_Saf_pct*median_Saf median_Saf,
median_FR_pct*median_FR median_FR,
median_Blk_pct*median_Blk median_Blk,
median_TD_pct*median_TD median_TD,
median_PA_pct*median_PA median_PA,
median_PassYdsDST_pct*median_PassYdsDST median_PassYdsDST,
median_RushYdsDST_pct*median_RushYdsDST median_RushYdsDST,
median_TotYdsDST_pct*median_TotYdsDST median_TotYdsDST
from 
(select * from analytics_area_all_positions_prev_pct_median where week = @p_week) analytics_area_all_positions_prev_pct_median join
(select * from pool_area_all_positions_by_week where week = @p_week) pool_area_all_positions_by_week
on (analytics_area_all_positions_prev_pct_median.id_Player = pool_area_all_positions_by_week.id_player) join
(select * from pool_area_schedule where week = @p_week+1) pool_area_schedule
on (pool_area_all_positions_by_week.team = pool_area_schedule.team)
join
(select * from analytics_area_all_positions_opponent_prev_median where week = @p_week) analytics_area_all_positions_opponent_prev_median 
on (pool_area_schedule.opponent = analytics_area_all_positions_opponent_prev_median.opponent and analytics_area_all_positions_prev_pct_median.position = analytics_area_all_positions_opponent_prev_median.position))a join 
[dbo].[stage_area_points]
on (1=1)
) a ;


delete from analytics_area_all_positions_pts_acc_to_opponent_last_3_week where week = @p_week+1;
insert into analytics_area_all_positions_pts_acc_to_opponent_last_3_week
select a.*, (median_pts+pts_calc) / 2 pts
from
(select a.*,
isnull([median_PassYds],0)*isnull(stage_area_points.[PassYds],0) +
isnull([median_PassTD],0)*isnull(stage_area_points.[PassTD],0) +
isnull([median_PassInt],0)*isnull(stage_area_points.[PassInt],0) +
isnull([median_Pass2Pt],0)*isnull(stage_area_points.[Pass2Pt],0) +   
isnull([median_RushYds],0)*isnull(stage_area_points.[RushYds],0) +   
isnull([median_RushTD],0)*isnull(stage_area_points.[RushTD],0) +   
isnull([median_Rush2Pt],0)*isnull(stage_area_points.[Rush2Pt],0) +   
isnull([median_RecRec],0)*isnull(stage_area_points.[RecRec],0) +   
isnull([median_RecYds],0)*isnull(stage_area_points.[RecYds],0) +   
isnull([median_RecTD],0)*isnull(stage_area_points.[RecTD],0) +   
isnull([median_Rec2Pt],0)*isnull(stage_area_points.[Rec2Pt],0) +   
isnull([median_FumFL],0)*isnull(stage_area_points.[FumFL],0) +   
isnull([median_FumTD],0)*isnull(stage_area_points.[FumTD],0) +   
(isnull([median_XPA],0)-isnull([median_XPM],0))*isnull(stage_area_points.[XPMissed],0) +   
isnull([median_XPM],0)*isnull(stage_area_points.[XPMade],0) +   
(isnull([median_FGA],0)-isnull([median_FGM],0))*isnull(stage_area_points.[FGMissed],0) +   
isnull([median_FGM],0)*isnull(stage_area_points.[FGMade],0) +   
isnull([median_50+],0)*isnull(stage_area_points.[50+],0) +   
isnull([median_Sack],0)*isnull(stage_area_points.[Sack],0) +   
isnull([median_Int],0)*isnull(stage_area_points.[Int],0) +   
isnull([median_Saf],0)*isnull(stage_area_points.[Saf],0) +   
isnull([median_FR],0)*isnull(stage_area_points.[FR],0) +   
isnull([median_Blk],0)*isnull(stage_area_points.[Blk],0) +   
isnull([median_TD],0)*isnull(stage_area_points.[TD],0) +   
CASE 
WHEN [median_PA] = 0 then stage_area_points.[PA 0]
WHEN [median_PA] between 1 and 6 then stage_area_points.[PA 6]
WHEN [median_PA] between 7 and 13 then stage_area_points.[PA 13]
WHEN [median_PA] between 14 and 20 then stage_area_points.[PA 20]
WHEN [median_PA] between 28 and 34 then stage_area_points.[PA 34]
WHEN [median_PA] >= 35 then stage_area_points.[PA 35]
else 0 
end +
CASE 
WHEN [median_TotYdsDST] < 100 then stage_area_points.[TotYdsDST 100]
WHEN [median_TotYdsDST] between 100 and 199 then stage_area_points.[TotYdsDST 199]
WHEN [median_TotYdsDST] between 200 and 299 then stage_area_points.[TotYdsDST 299]
WHEN [median_TotYdsDST] between 350 and 399 then stage_area_points.[TotYdsDST 399]
WHEN [median_TotYdsDST] between 400 and 449 then stage_area_points.[TotYdsDST 449]
WHEN [median_TotYdsDST] between 450 and 499 then stage_area_points.[TotYdsDST 499] 
WHEN [median_TotYdsDST] between 500 and 549 then stage_area_points.[TotYdsDST 549]
WHEN [median_TotYdsDST] >= 550 then stage_area_points.[TotYdsDST 550]
else 0
end 
pts_calc
from
(select 
analytics_area_all_positions_prev_pct_median_last_3_week.id_Player,
analytics_area_all_positions_prev_pct_median_last_3_week.player,
analytics_area_all_positions_prev_pct_median_last_3_week.position,
analytics_area_all_positions_prev_pct_median_last_3_week.week+1 week,
median_pts_pct*median_pts median_pts,
median_PassAtt_pct*median_PassAtt median_PassAtt,
median_PassCmp_pct*median_PassCmp median_PassCmp,
median_PassYds_pct*median_PassYds median_PassYds,
median_PassTD_pct*median_PassTD median_PassTD,
median_PassInt_pct*median_PassInt median_PassInt,
median_Pass2Pt_pct*median_Pass2Pt median_Pass2Pt,
median_RushAtt_pct*median_RushAtt median_RushAtt,
median_RushYds_pct*median_RushYds median_RushYds,
median_RushTD_pct*median_RushTD median_RushTD,
median_Rush2Pt_pct*median_Rush2Pt median_Rush2Pt,
median_RecRec_pct*median_RecRec median_RecRec,
median_RecYds_pct*median_RecYds median_RecYds,
median_RecTD_pct*median_RecTD median_RecTD,
median_Rec2Pt_pct*median_Rec2Pt median_Rec2Pt,
median_FumFL_pct*median_FumFL median_FumFL,
median_FumTD_pct*median_FumTD median_FumTD,
median_XPA_pct*median_XPA median_XPA,
median_XPM_pct*median_XPM median_XPM,
median_FGA_pct*median_FGA median_FGA,
median_FGM_pct*median_FGM median_FGM,
[median_50+_pct]*[median_50+] [median_50+],
median_Sack_pct*median_Sack median_Sack,
median_Int_pct*median_Int median_Int,
median_Saf_pct*median_Saf median_Saf,
median_FR_pct*median_FR median_FR,
median_Blk_pct*median_Blk median_Blk,
median_TD_pct*median_TD median_TD,
median_PA_pct*median_PA median_PA,
median_PassYdsDST_pct*median_PassYdsDST median_PassYdsDST,
median_RushYdsDST_pct*median_RushYdsDST median_RushYdsDST,
median_TotYdsDST_pct*median_TotYdsDST median_TotYdsDST
from 
(select * from analytics_area_all_positions_prev_pct_median_last_3_week where week = @p_week) analytics_area_all_positions_prev_pct_median_last_3_week join
(select * from pool_area_all_positions_by_week where week = @p_week) pool_area_all_positions_by_week
on (analytics_area_all_positions_prev_pct_median_last_3_week.id_Player = pool_area_all_positions_by_week.id_player) join
(select * from pool_area_schedule where week = @p_week+1) pool_area_schedule
on (pool_area_all_positions_by_week.team = pool_area_schedule.team)
join
(select * from analytics_area_all_positions_opponent_prev_median_last_3_week where week = @p_week) analytics_area_all_positions_opponent_prev_median_last_3_week 
on (pool_area_schedule.opponent = analytics_area_all_positions_opponent_prev_median_last_3_week.opponent and analytics_area_all_positions_prev_pct_median_last_3_week.position = analytics_area_all_positions_opponent_prev_median_last_3_week.position))a join 
[dbo].[stage_area_points]
on (1=1)
) a ;

delete from analytics_area_all_positions_pts_acc_to_self where week = @p_week+1;
insert into analytics_area_all_positions_pts_acc_to_self
select 
a.id_player,
a.player,
a.position,
a.team,
a.week+1 week,
a.median_pts_pct,
a.median_pts_PassAtt,
a.median_pts_PassCmp,
a.median_pts_PassYds,
a.median_pts_PassTD,
a.median_pts_PassInt,
a.median_pts_Pass2Pt,
a.median_pts_RushAtt,
a.median_pts_RushYds,
a.median_pts_RushTD,
a.median_pts_Rush2Pt,
a.median_pts_RecRec,
a.median_pts_RecYds,
a.median_pts_RecTD,
a.median_pts_Rec2Pt,
a.median_pts_FumFL,
a.median_pts_FumTD,
a.median_pts_XPA,
a.median_pts_XPM,
a.median_pts_FGA,
a.median_pts_FGM,
a.[median_pts_50+],
a.median_pts_Sack,
a.median_pts_Int,
a.median_pts_Saf,
a.median_pts_FR,
a.median_pts_Blk,
a.median_pts_TD,
a.median_pts_PA,
a.median_pts_PassYdsDST,
a.median_pts_RushYdsDST,
a.median_pts_TotYdsDST,
a.pts_calc,
(median_pts_pct+pts_calc) / 2 pts
from
(
select analytics_area_all_positions_prev_median.*,
isnull([median_pts_PassYds],0)*isnull(stage_area_points.[PassYds],0) +
isnull([median_pts_PassTD],0)*isnull(stage_area_points.[PassTD],0) +
isnull([median_pts_PassInt],0)*isnull(stage_area_points.[PassInt],0) +
isnull([median_pts_Pass2Pt],0)*isnull(stage_area_points.[Pass2Pt],0) +   
isnull([median_pts_RushYds],0)*isnull(stage_area_points.[RushYds],0) +   
isnull([median_pts_RushTD],0)*isnull(stage_area_points.[RushTD],0) +   
isnull([median_pts_Rush2Pt],0)*isnull(stage_area_points.[Rush2Pt],0) +   
isnull([median_pts_RecRec],0)*isnull(stage_area_points.[RecRec],0) +   
isnull([median_pts_RecYds],0)*isnull(stage_area_points.[RecYds],0) +   
isnull([median_pts_RecTD],0)*isnull(stage_area_points.[RecTD],0) +   
isnull([median_pts_Rec2Pt],0)*isnull(stage_area_points.[Rec2Pt],0) +   
isnull([median_pts_FumFL],0)*isnull(stage_area_points.[FumFL],0) +   
isnull([median_pts_FumTD],0)*isnull(stage_area_points.[FumTD],0) +   
(isnull([median_pts_XPA],0)-isnull([median_pts_XPM],0))*isnull(stage_area_points.[XPMissed],0) +   
isnull([median_pts_XPM],0)*isnull(stage_area_points.[XPMade],0) +   
(isnull([median_pts_FGA],0)-isnull([median_pts_FGM],0))*isnull(stage_area_points.[FGMissed],0) +   
isnull([median_pts_FGM],0)*isnull(stage_area_points.[FGMade],0) +   
isnull([median_pts_50+],0)*isnull(stage_area_points.[50+],0) +   
isnull([median_pts_Sack],0)*isnull(stage_area_points.[Sack],0) +   
isnull([median_pts_Int],0)*isnull(stage_area_points.[Int],0) +   
isnull([median_pts_Saf],0)*isnull(stage_area_points.[Saf],0) +   
isnull([median_pts_FR],0)*isnull(stage_area_points.[FR],0) +   
isnull([median_pts_Blk],0)*isnull(stage_area_points.[Blk],0) +   
isnull([median_pts_TD],0)*isnull(stage_area_points.[TD],0) +   
CASE 
WHEN [median_pts_PA] = 0 then stage_area_points.[PA 0]
WHEN [median_pts_PA] between 1 and 6 then stage_area_points.[PA 6]
WHEN [median_pts_PA] between 7 and 13 then stage_area_points.[PA 13]
WHEN [median_pts_PA] between 14 and 20 then stage_area_points.[PA 20]
WHEN [median_pts_PA] between 28 and 34 then stage_area_points.[PA 34]
WHEN [median_pts_PA] >= 35 then stage_area_points.[PA 35]
else 0 
end +
CASE 
WHEN [median_pts_TotYdsDST] < 100 then stage_area_points.[TotYdsDST 100]
WHEN [median_pts_TotYdsDST] between 100 and 199 then stage_area_points.[TotYdsDST 199]
WHEN [median_pts_TotYdsDST] between 200 and 299 then stage_area_points.[TotYdsDST 299]
WHEN [median_pts_TotYdsDST] between 350 and 399 then stage_area_points.[TotYdsDST 399]
WHEN [median_pts_TotYdsDST] between 400 and 449 then stage_area_points.[TotYdsDST 449]
WHEN [median_pts_TotYdsDST] between 450 and 499 then stage_area_points.[TotYdsDST 499] 
WHEN [median_pts_TotYdsDST] between 500 and 549 then stage_area_points.[TotYdsDST 549]
WHEN [median_pts_TotYdsDST] >= 550 then stage_area_points.[TotYdsDST 550]
else 0
end 
pts_calc
from 
(select * from analytics_area_all_positions_prev_median where week = @p_week) analytics_area_all_positions_prev_median join 
[dbo].[stage_area_points]
on (1=1)
) a ;

delete from analytics_area_all_positions_pts_acc_to_self_last_3_week where week = @p_week+1;
insert into analytics_area_all_positions_pts_acc_to_self_last_3_week
select a.id_player,
a.player,
a.position,
a.team,
a.week+1 week,
a.median_pts_pct,
a.median_pts_PassAtt,
a.median_pts_PassCmp,
a.median_pts_PassYds,
a.median_pts_PassTD,
a.median_pts_PassInt,
a.median_pts_Pass2Pt,
a.median_pts_RushAtt,
a.median_pts_RushYds,
a.median_pts_RushTD,
a.median_pts_Rush2Pt,
a.median_pts_RecRec,
a.median_pts_RecYds,
a.median_pts_RecTD,
a.median_pts_Rec2Pt,
a.median_pts_FumFL,
a.median_pts_FumTD,
a.median_pts_XPA,
a.median_pts_XPM,
a.median_pts_FGA,
a.median_pts_FGM,
a.[median_pts_50+],
a.median_pts_Sack,
a.median_pts_Int,
a.median_pts_Saf,
a.median_pts_FR,
a.median_pts_Blk,
a.median_pts_TD,
a.median_pts_PA,
a.median_pts_PassYdsDST,
a.median_pts_RushYdsDST,
a.median_pts_TotYdsDST,
a.pts_calc, 
(median_pts_pct+pts_calc) / 2 pts
from
(
select analytics_area_all_positions_prev_median_last_3_week.*,
isnull([median_pts_PassYds],0)*isnull(stage_area_points.[PassYds],0) +
isnull([median_pts_PassTD],0)*isnull(stage_area_points.[PassTD],0) +
isnull([median_pts_PassInt],0)*isnull(stage_area_points.[PassInt],0) +
isnull([median_pts_Pass2Pt],0)*isnull(stage_area_points.[Pass2Pt],0) +   
isnull([median_pts_RushYds],0)*isnull(stage_area_points.[RushYds],0) +   
isnull([median_pts_RushTD],0)*isnull(stage_area_points.[RushTD],0) +   
isnull([median_pts_Rush2Pt],0)*isnull(stage_area_points.[Rush2Pt],0) +   
isnull([median_pts_RecRec],0)*isnull(stage_area_points.[RecRec],0) +   
isnull([median_pts_RecYds],0)*isnull(stage_area_points.[RecYds],0) +   
isnull([median_pts_RecTD],0)*isnull(stage_area_points.[RecTD],0) +   
isnull([median_pts_Rec2Pt],0)*isnull(stage_area_points.[Rec2Pt],0) +   
isnull([median_pts_FumFL],0)*isnull(stage_area_points.[FumFL],0) +   
isnull([median_pts_FumTD],0)*isnull(stage_area_points.[FumTD],0) +   
(isnull([median_pts_XPA],0)-isnull([median_pts_XPM],0))*isnull(stage_area_points.[XPMissed],0) +   
isnull([median_pts_XPM],0)*isnull(stage_area_points.[XPMade],0) +   
(isnull([median_pts_FGA],0)-isnull([median_pts_FGM],0))*isnull(stage_area_points.[FGMissed],0) +   
isnull([median_pts_FGM],0)*isnull(stage_area_points.[FGMade],0) +   
isnull([median_pts_50+],0)*isnull(stage_area_points.[50+],0) +   
isnull([median_pts_Sack],0)*isnull(stage_area_points.[Sack],0) +   
isnull([median_pts_Int],0)*isnull(stage_area_points.[Int],0) +   
isnull([median_pts_Saf],0)*isnull(stage_area_points.[Saf],0) +   
isnull([median_pts_FR],0)*isnull(stage_area_points.[FR],0) +   
isnull([median_pts_Blk],0)*isnull(stage_area_points.[Blk],0) +   
isnull([median_pts_TD],0)*isnull(stage_area_points.[TD],0) +   
CASE 
WHEN [median_pts_PA] = 0 then stage_area_points.[PA 0]
WHEN [median_pts_PA] between 1 and 6 then stage_area_points.[PA 6]
WHEN [median_pts_PA] between 7 and 13 then stage_area_points.[PA 13]
WHEN [median_pts_PA] between 14 and 20 then stage_area_points.[PA 20]
WHEN [median_pts_PA] between 28 and 34 then stage_area_points.[PA 34]
WHEN [median_pts_PA] >= 35 then stage_area_points.[PA 35]
else 0 
end +
CASE 
WHEN [median_pts_TotYdsDST] < 100 then stage_area_points.[TotYdsDST 100]
WHEN [median_pts_TotYdsDST] between 100 and 199 then stage_area_points.[TotYdsDST 199]
WHEN [median_pts_TotYdsDST] between 200 and 299 then stage_area_points.[TotYdsDST 299]
WHEN [median_pts_TotYdsDST] between 350 and 399 then stage_area_points.[TotYdsDST 399]
WHEN [median_pts_TotYdsDST] between 400 and 449 then stage_area_points.[TotYdsDST 449]
WHEN [median_pts_TotYdsDST] between 450 and 499 then stage_area_points.[TotYdsDST 499] 
WHEN [median_pts_TotYdsDST] between 500 and 549 then stage_area_points.[TotYdsDST 549]
WHEN [median_pts_TotYdsDST] >= 550 then stage_area_points.[TotYdsDST 550]
else 0
end 
pts_calc
from 
(select * from analytics_area_all_positions_prev_median_last_3_week where week = @p_week) analytics_area_all_positions_prev_median_last_3_week join 
[dbo].[stage_area_points]
on (1=1)
) a ;

delete from analytics_area_all_positions_pts_prediction where week = @p_week +1;
insert into analytics_area_all_positions_pts_prediction (id_player,player,position,team,week,pts)
select 
analytics_area_all_positions_pts_acc_to_self.id_player, 
analytics_area_all_positions_pts_acc_to_self.player, 
analytics_area_all_positions_pts_acc_to_self.position, 
analytics_area_all_positions_pts_acc_to_self.team, 
analytics_area_all_positions_pts_acc_to_self.week week,
(analytics_area_all_positions_pts_acc_to_self.pts+analytics_area_all_positions_pts_acc_to_opponent.pts)/2 pts 
from
(select id_player, player, position, team, week, pts from analytics_area_all_positions_pts_acc_to_self where week = @p_week+1) analytics_area_all_positions_pts_acc_to_self join
(select id_player, player, position, week, pts from analytics_area_all_positions_pts_acc_to_opponent where week = @p_week+1) analytics_area_all_positions_pts_acc_to_opponent
on (analytics_area_all_positions_pts_acc_to_self.id_player = analytics_area_all_positions_pts_acc_to_opponent.id_player);

delete from analytics_area_all_positions_pts_prediction_last_3_week where week = @p_week +1;
insert into analytics_area_all_positions_pts_prediction_last_3_week (id_player,player,position,team,week,pts)
select 
analytics_area_all_positions_pts_acc_to_self_last_3_week.id_player, 
analytics_area_all_positions_pts_acc_to_self_last_3_week.player, 
analytics_area_all_positions_pts_acc_to_self_last_3_week.position, 
analytics_area_all_positions_pts_acc_to_self_last_3_week.team, 
analytics_area_all_positions_pts_acc_to_self_last_3_week.week week,
(analytics_area_all_positions_pts_acc_to_self_last_3_week.pts+analytics_area_all_positions_pts_acc_to_opponent_last_3_week.pts)/2 pts 
from
(select id_player, player, position, team, week, pts from analytics_area_all_positions_pts_acc_to_self_last_3_week where week = @p_week+1) analytics_area_all_positions_pts_acc_to_self_last_3_week join
(select id_player, player, position, week, pts from analytics_area_all_positions_pts_acc_to_opponent_last_3_week where week = @p_week+1) analytics_area_all_positions_pts_acc_to_opponent_last_3_week
on (analytics_area_all_positions_pts_acc_to_self_last_3_week.id_player = analytics_area_all_positions_pts_acc_to_opponent_last_3_week.id_player);


delete from analytics_area_all_positions_pts_deviation where week = @p_week+1
insert into analytics_area_all_positions_pts_deviation
select 
analytics_area_all_positions_pts_prediction.id_player,	
analytics_area_all_positions_pts_prediction.player,	
analytics_area_all_positions_pts_prediction.position,
analytics_area_all_positions_pts_prediction.team,	
analytics_area_all_positions_pts_prediction.week,
analytics_area_all_positions_pts_prediction.pts pts_predicted,
pool_area_all_positions_by_week.pts pts_actual,
pool_area_all_positions_by_week.pts-analytics_area_all_positions_pts_prediction.pts deviation
from 
(select * from analytics_area_all_positions_pts_prediction where week = @p_week+1) analytics_area_all_positions_pts_prediction join
(select * from 
(select pool_area_all_positions_by_week.*, max(week) over (partition by id_player) max_week from pool_area_all_positions_by_week where week <= @p_week and pts is not null) a
where week = max_week) pool_area_all_positions_by_week
on (analytics_area_all_positions_pts_prediction.id_player = pool_area_all_positions_by_week.id_player);

delete from analytics_area_all_positions_pts_deviation_last_3_week where week = @p_week+1
insert into analytics_area_all_positions_pts_deviation_last_3_week
select 
analytics_area_all_positions_pts_prediction_last_3_week.id_player,	
analytics_area_all_positions_pts_prediction_last_3_week.player,	
analytics_area_all_positions_pts_prediction_last_3_week.position,
analytics_area_all_positions_pts_prediction_last_3_week.team,	
analytics_area_all_positions_pts_prediction_last_3_week.week,
analytics_area_all_positions_pts_prediction_last_3_week.pts pts_predicted,
pool_area_all_positions_by_week.pts pts_actual,
pool_area_all_positions_by_week.pts-analytics_area_all_positions_pts_prediction_last_3_week.pts deviation
from 
(select * from analytics_area_all_positions_pts_prediction_last_3_week where week = @p_week+1) analytics_area_all_positions_pts_prediction_last_3_week join
(select * from 
(select pool_area_all_positions_by_week.*, max(week) over (partition by id_player) max_week from pool_area_all_positions_by_week where week <= @p_week and pts is not null) a
where week = max_week) pool_area_all_positions_by_week
on (analytics_area_all_positions_pts_prediction_last_3_week.id_player = pool_area_all_positions_by_week.id_player);

delete from analytics_area_all_positions_pts_deviation_correction where week = @p_week+1;
insert into analytics_area_all_positions_pts_deviation_correction
select distinct
id_player, 
player, 
position, 
@p_week+1 week,
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY deviation) over (partition by id_player) as median_deviation,	
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY positive_deviation) over (partition by id_player) as median_positive_deviation,
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY negative_deviation) over (partition by id_player) as median_negative_deviation
from (
    SELECT 
        id_player,
		player, 
		position, 
        deviation,
        CASE WHEN deviation > 0 THEN deviation END AS positive_deviation,
        CASE WHEN deviation < 0 THEN deviation END AS negative_deviation
    FROM analytics_area_all_positions_pts_deviation where week <= @p_week+1
) a;

delete from analytics_area_all_positions_pts_deviation_correction_last_3_week where week = @p_week+1;
insert into analytics_area_all_positions_pts_deviation_correction_last_3_week
select distinct
id_player, 
player, 
position, 
@p_week+1 week,
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY deviation) over (partition by id_player) as median_deviation,	
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY positive_deviation) over (partition by id_player) as median_positive_deviation,
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY negative_deviation) over (partition by id_player) as median_negative_deviation
from (
    SELECT 
        id_player,
		player, 
		position, 
        deviation,
        CASE WHEN deviation > 0 THEN deviation END AS positive_deviation,
        CASE WHEN deviation < 0 THEN deviation END AS negative_deviation
    FROM analytics_area_all_positions_pts_deviation_last_3_week where week <= @p_week+1
) a;

delete from analytics_area_opponent_pts_deviation_correction where week = @p_week+1;
insert into analytics_area_opponent_pts_deviation_correction
SELECT a.id_player, a.player, a.position, @p_week+1 week,
a.median_deviation*analytics_area_all_positions_prev_pct.sum_pts_pct median_deviation,	
a.median_positive_deviation*analytics_area_all_positions_prev_pct.sum_pts_pct median_positive_deviation,
a.median_negative_deviation*analytics_area_all_positions_prev_pct.sum_pts_pct median_negative_deviation
FROM 
(select * 
from
(
select distinct
id_player, player, position, week, max_week,team, opponent,pts_predicted,sum_pts_predicted,pts_actual,sum_pts_actual,
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY deviation) over (partition by id_player) as median_deviation,	
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY positive_deviation) over (partition by id_player) as median_positive_deviation,
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY negative_deviation) over (partition by id_player) as median_negative_deviation
from
(
SELECT id_player, player, position, week,max_week, team, opponent,pts_predicted,sum_pts_predicted,pts_actual,sum_pts_actual,
deviation,
CASE WHEN deviation > 0 THEN deviation END AS positive_deviation,
CASE WHEN deviation < 0 THEN deviation END AS negative_deviation
FROM
(
select id_player, player, position, week,max_week, team, opponent,pts_predicted,sum_pts_predicted,pts_actual,sum_pts_actual,
sum_pts_actual-sum_pts_predicted deviation
from
(
select id_player, player, position, week, team, opponent, max(week) over (partition by id_player) max_week,
pts_predicted,
sum(pts_predicted) over (partition by team, opponent, position, week) sum_pts_predicted, 
pts_actual, 
sum(pts_actual) over (partition by team, opponent, position, week) sum_pts_actual
from
(
select a.*
from
(
select 
analytics_area_all_positions_pts_acc_to_opponent.id_Player,
analytics_area_all_positions_pts_acc_to_opponent.player,
analytics_area_all_positions_pts_acc_to_opponent.position,
analytics_area_all_positions_pts_acc_to_opponent.week week,
analytics_area_all_positions_pts_acc_to_opponent.median_pts,
analytics_area_all_positions_pts_acc_to_opponent.pts_calc,	
analytics_area_all_positions_pts_acc_to_opponent.pts pts_predicted, 
pool_area_all_positions_by_week.team,
pool_area_all_positions_by_week.opponent,
pool_area_all_positions_by_week.pts pts_actual
from (select * from analytics_area_all_positions_pts_acc_to_opponent where week <= @p_week) analytics_area_all_positions_pts_acc_to_opponent join
(select * from pool_area_all_positions_by_week where week <= @p_week) pool_area_all_positions_by_week
on 
(
analytics_area_all_positions_pts_acc_to_opponent.id_player = pool_area_all_positions_by_week.id_player and
analytics_area_all_positions_pts_acc_to_opponent.week = pool_area_all_positions_by_week.week
) 
) a 
) a 
) a 
) a
) a
) a where week = max_week
) a join
(
SELECT id_player,player,position,team,week,
sum_pts_pct_player/
case 
when sum(sum_pts_pct_temp) over (PARTITION BY id_player ORDER BY week ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) = 0 
then 1 
else sum(sum_pts_pct_temp) over (PARTITION BY id_player ORDER BY week ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) 
end
sum_pts_pct
FROM
(
select analytics_area_all_positions_prev_pct.*,
sum(pts_pct) over (PARTITION BY id_player ORDER BY week ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) sum_pts_pct_player,
sum(pts_pct) over (PARTITION BY team, position, week) sum_pts_pct_temp
from analytics_area_all_positions_prev_pct
) A
) analytics_area_all_positions_prev_pct
on 
(
a.id_player=analytics_area_all_positions_prev_pct.id_player and
a.week=analytics_area_all_positions_prev_pct.week
);


delete from analytics_area_opponent_pts_deviation_correction_last_3_week where week = @p_week+1;
insert into analytics_area_opponent_pts_deviation_correction_last_3_week
SELECT a.id_player, a.player, a.position, @p_week+1 week,
a.median_deviation*analytics_area_all_positions_prev_pct.sum_pts_pct median_deviation,	
a.median_positive_deviation*analytics_area_all_positions_prev_pct.sum_pts_pct median_positive_deviation,
a.median_negative_deviation*analytics_area_all_positions_prev_pct.sum_pts_pct median_negative_deviation
FROM (
select * 
from
(
select distinct
id_player, player, position, week, max_week,team, opponent,pts_predicted,sum_pts_predicted,pts_actual,sum_pts_actual,
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY deviation) over (partition by id_player) as median_deviation,	
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY positive_deviation) over (partition by id_player) as median_positive_deviation,
PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY negative_deviation) over (partition by id_player) as median_negative_deviation
from
(
SELECT id_player, player, position, week, max_week,team, opponent,pts_predicted,sum_pts_predicted,pts_actual,sum_pts_actual,
deviation,
CASE WHEN deviation > 0 THEN deviation END AS positive_deviation,
CASE WHEN deviation < 0 THEN deviation END AS negative_deviation
FROM
(
select id_player, player, position, week, max_week,team, opponent,pts_predicted,sum_pts_predicted,pts_actual,sum_pts_actual,
sum_pts_actual-sum_pts_predicted deviation
from
(
select id_player, player, position, week, team, opponent,max(week) over (partition by id_player) max_week,
pts_predicted,
sum(pts_predicted) over (partition by team, opponent, position, week) sum_pts_predicted, 
pts_actual, 
sum(pts_actual) over (partition by team, opponent, position, week) sum_pts_actual
from
(
select a.*
from
(
select 
analytics_area_all_positions_pts_acc_to_opponent_last_3_week.id_Player,
analytics_area_all_positions_pts_acc_to_opponent_last_3_week.player,
analytics_area_all_positions_pts_acc_to_opponent_last_3_week.position,
analytics_area_all_positions_pts_acc_to_opponent_last_3_week.week,
analytics_area_all_positions_pts_acc_to_opponent_last_3_week.median_pts,
analytics_area_all_positions_pts_acc_to_opponent_last_3_week.pts_calc,	
analytics_area_all_positions_pts_acc_to_opponent_last_3_week.pts pts_predicted, 
pool_area_all_positions_by_week.team,
pool_area_all_positions_by_week.opponent,
pool_area_all_positions_by_week.pts pts_actual
from (select * from analytics_area_all_positions_pts_acc_to_opponent_last_3_week where week <= @p_week) analytics_area_all_positions_pts_acc_to_opponent_last_3_week join
(select * from pool_area_all_positions_by_week where week <= @p_week) pool_area_all_positions_by_week
on 
(
analytics_area_all_positions_pts_acc_to_opponent_last_3_week.id_player = pool_area_all_positions_by_week.id_player and
analytics_area_all_positions_pts_acc_to_opponent_last_3_week.week = pool_area_all_positions_by_week.week
) 
) a 
) a 
) a 
) a
) a
) a where week = max_week
) a join
(
SELECT id_player,player,position,team,week,
sum_pts_pct_player/
case 
when sum(sum_pts_pct_temp) over (PARTITION BY id_player ORDER BY week ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) = 0 
then 1 
else sum(sum_pts_pct_temp) over (PARTITION BY id_player ORDER BY week ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) 
end
sum_pts_pct
FROM
(
select analytics_area_all_positions_prev_pct.*,
sum(pts_pct) over (PARTITION BY id_player ORDER BY week ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) sum_pts_pct_player,
sum(pts_pct) over (PARTITION BY team,  position, week) sum_pts_pct_temp
from analytics_area_all_positions_prev_pct
) A
) analytics_area_all_positions_prev_pct
on 
(
a.id_player=analytics_area_all_positions_prev_pct.id_player and
a.week=analytics_area_all_positions_prev_pct.week
);

merge into analytics_area_all_positions_pts_prediction using
(
select 
analytics_area_all_positions_pts_deviation_correction.id_player,
analytics_area_all_positions_pts_deviation_correction.player,
analytics_area_all_positions_pts_deviation_correction.position,
analytics_area_all_positions_pts_deviation_correction.week,
(isnull(analytics_area_all_positions_pts_deviation_correction.median_deviation,0)+isnull(analytics_area_opponent_pts_deviation_correction.median_deviation,0))/2 median_deviation,
(isnull(analytics_area_all_positions_pts_deviation_correction.median_positive_deviation,0)+isnull(analytics_area_opponent_pts_deviation_correction.median_positive_deviation,0))/2 median_positive_deviation,
(isnull(analytics_area_all_positions_pts_deviation_correction.median_negative_deviation,0)+isnull(analytics_area_opponent_pts_deviation_correction.median_negative_deviation,0))/2 median_negative_deviation
from 
(select * from analytics_area_all_positions_pts_deviation_correction where week = @p_week+1) analytics_area_all_positions_pts_deviation_correction join
(select * from analytics_area_opponent_pts_deviation_correction where week = @p_week+1) analytics_area_opponent_pts_deviation_correction on
analytics_area_opponent_pts_deviation_correction.id_player = analytics_area_all_positions_pts_deviation_correction.id_player
) subq
on 
(
analytics_area_all_positions_pts_prediction.week = subq.week and
analytics_area_all_positions_pts_prediction.id_player = subq.id_player
)
when matched then update set
analytics_area_all_positions_pts_prediction.pts=analytics_area_all_positions_pts_prediction.pts+subq.median_deviation,
analytics_area_all_positions_pts_prediction.floor=analytics_area_all_positions_pts_prediction.pts+subq.median_negative_deviation,
analytics_area_all_positions_pts_prediction.ceiling=analytics_area_all_positions_pts_prediction.pts+subq.median_positive_deviation;

merge into analytics_area_all_positions_pts_prediction_last_3_week using
(
select 
analytics_area_all_positions_pts_deviation_correction_last_3_week.id_player,
analytics_area_all_positions_pts_deviation_correction_last_3_week.player,
analytics_area_all_positions_pts_deviation_correction_last_3_week.position,
analytics_area_all_positions_pts_deviation_correction_last_3_week.week,
(isnull(analytics_area_all_positions_pts_deviation_correction_last_3_week.median_deviation,0)+isnull(analytics_area_opponent_pts_deviation_correction_last_3_week.median_deviation,0))/2 median_deviation,
(isnull(analytics_area_all_positions_pts_deviation_correction_last_3_week.median_positive_deviation,0)+isnull(analytics_area_opponent_pts_deviation_correction_last_3_week.median_positive_deviation,0))/2 median_positive_deviation,
(isnull(analytics_area_all_positions_pts_deviation_correction_last_3_week.median_negative_deviation,0)+isnull(analytics_area_opponent_pts_deviation_correction_last_3_week.median_negative_deviation,0))/2 median_negative_deviation
from 
(select * from analytics_area_all_positions_pts_deviation_correction_last_3_week where week = @p_week+1) analytics_area_all_positions_pts_deviation_correction_last_3_week join
(select * from analytics_area_opponent_pts_deviation_correction_last_3_week where week = @p_week+1) analytics_area_opponent_pts_deviation_correction_last_3_week on
analytics_area_opponent_pts_deviation_correction_last_3_week.id_player = analytics_area_all_positions_pts_deviation_correction_last_3_week.id_player
) subq
on 
(
analytics_area_all_positions_pts_prediction_last_3_week.week = subq.week and
analytics_area_all_positions_pts_prediction_last_3_week.id_player = subq.id_player
)
when matched then update set
analytics_area_all_positions_pts_prediction_last_3_week.pts=analytics_area_all_positions_pts_prediction_last_3_week.pts+subq.median_deviation,
analytics_area_all_positions_pts_prediction_last_3_week.floor=analytics_area_all_positions_pts_prediction_last_3_week.pts+subq.median_negative_deviation,
analytics_area_all_positions_pts_prediction_last_3_week.ceiling=analytics_area_all_positions_pts_prediction_last_3_week.pts+subq.median_positive_deviation;
end;

drop FUNCTION if exists f_GetPlayerPredictionsWeekRoster;
CREATE FUNCTION f_GetPlayerPredictionsWeekRoster (@p_week INT, @p_roster_id int)
RETURNS TABLE
AS
RETURN
(
select distinct
a.player,a.position,a.team,a.week,a.pts_final,a.floor_final,a.ceiling_final,a.pts_actual,a.pct_error,a.is_miss,a.pts_all,a.floor_all,a.ceiling_all,a.pts_l3,a.floor_l3,a.ceiling_l3,a.pts_acc_to_self,a.pts_acc_to_opponent
from (
select 
id_player,
player,	
position,
team,
week,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_final,1)
when position in ('QB') THEN ROUND(pts_final,2)
when position in ('DST','K') THEN ROUND(pts_final,0)
END pts_final,
case 
when position in ('WR','TE','RB') THEN ROUND(floor_final,1)
when position in ('QB') THEN ROUND(floor_final,2)
when position in ('DST','K') THEN ROUND(floor_final,0)
END floor_final,
case 
when position in ('WR','TE','RB') THEN ROUND(ceiling_final,1)
when position in ('QB') THEN ROUND(ceiling_final,2)
when position in ('DST','K') THEN ROUND(ceiling_final,0)
END ceiling_final,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_actual,1)
when position in ('QB') THEN ROUND(pts_actual,2)
when position in ('DST','K') THEN ROUND(pts_actual,0)
END pts_actual,
pct_error,
is_miss,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_all,1)
when position in ('QB') THEN ROUND(pts_all,2)
when position in ('DST','K') THEN ROUND(pts_all,0)
END pts_all,
case 
when position in ('WR','TE','RB') THEN ROUND(floor_all,1)
when position in ('QB') THEN ROUND(floor_all,2)
when position in ('DST','K') THEN ROUND(floor_all,0)
END floor_all,
case 
when position in ('WR','TE','RB') THEN ROUND(ceiling_all,1)
when position in ('QB') THEN ROUND(ceiling_all,2)
when position in ('DST','K') THEN ROUND(ceiling_all,0)
END ceiling_all,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_l3,1)
when position in ('QB') THEN ROUND(pts_l3,2)
when position in ('DST','K') THEN ROUND(pts_l3,0)
END pts_l3,
case 
when position in ('WR','TE','RB') THEN ROUND(floor_l3,1)
when position in ('QB') THEN ROUND(floor_l3,2)
when position in ('DST','K') THEN ROUND(floor_l3,0)
END floor_l3,
case 
when position in ('WR','TE','RB') THEN ROUND(ceiling_l3,1)
when position in ('QB') THEN ROUND(ceiling_l3,2)
when position in ('DST','K') THEN ROUND(ceiling_l3,0)
END ceiling_l3,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_acc_to_self,1)
when position in ('QB') THEN ROUND(pts_acc_to_self,2)
when position in ('DST','K') THEN ROUND(pts_acc_to_self,0)
END pts_acc_to_self,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_acc_to_opponent,1)
when position in ('QB') THEN ROUND(pts_acc_to_opponent,2)
when position in ('DST','K') THEN ROUND(pts_acc_to_opponent,0)
END pts_acc_to_opponent
from 
(
select analytics_area_all_positions_pts_prediction.id_player, analytics_area_all_positions_pts_prediction.player,analytics_area_all_positions_pts_prediction.position, analytics_area_all_positions_pts_prediction.team, analytics_area_all_positions_pts_prediction.week, 
(analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2 pts_final,
(isnull(analytics_area_all_positions_pts_prediction.floor,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.floor,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2 floor_final,
(isnull(analytics_area_all_positions_pts_prediction.ceiling,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.ceiling,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2 ceiling_final,
pool_area_all_positions_by_week.pts pts_actual,
case 
when ((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2) <> 0
then abs(((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2)-pool_area_all_positions_by_week.pts)
     /
	 ((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2)*100 
when pool_area_all_positions_by_week.pts <> 0
then abs(((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2)-pool_area_all_positions_by_week.pts)
     /
	 pool_area_all_positions_by_week.pts*100  
else null 
end pct_error,
case 
when pool_area_all_positions_by_week.pts between (isnull(analytics_area_all_positions_pts_prediction.floor,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.floor,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2 and (isnull(analytics_area_all_positions_pts_prediction.ceiling,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.ceiling,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2
then 'NO'
WHEN pool_area_all_positions_by_week.pts IS NULL
THEN NULL
ELSE 'YES'
END is_miss,
analytics_area_all_positions_pts_prediction.pts pts_all, 
isnull(analytics_area_all_positions_pts_prediction.floor,analytics_area_all_positions_pts_prediction.pts) floor_all, 
isnull(analytics_area_all_positions_pts_prediction.ceiling,analytics_area_all_positions_pts_prediction.pts) ceiling_all,
analytics_area_all_positions_pts_prediction_last_3_week.pts pts_l3, 
isnull(analytics_area_all_positions_pts_prediction_last_3_week.floor,analytics_area_all_positions_pts_prediction_last_3_week.pts) floor_l3, 
isnull(analytics_area_all_positions_pts_prediction_last_3_week.ceiling,analytics_area_all_positions_pts_prediction_last_3_week.pts) ceiling_l3,
analytics_area_all_positions_pts_acc_to_self.pts pts_acc_to_self,
analytics_area_all_positions_pts_acc_to_opponent.pts pts_acc_to_opponent
from  (select * from analytics_area_all_positions_pts_prediction where week = @p_week+1) analytics_area_all_positions_pts_prediction join 
analytics_area_all_positions_pts_prediction_last_3_week
on  
(
analytics_area_all_positions_pts_prediction.id_player = analytics_area_all_positions_pts_prediction_last_3_week.id_player and
analytics_area_all_positions_pts_prediction.week = analytics_area_all_positions_pts_prediction_last_3_week.week 
)
join
analytics_area_all_positions_pts_acc_to_opponent
on 
(
analytics_area_all_positions_pts_prediction.id_player = analytics_area_all_positions_pts_acc_to_opponent.id_player and
analytics_area_all_positions_pts_prediction.week = analytics_area_all_positions_pts_acc_to_opponent.week 
)
join
analytics_area_all_positions_pts_acc_to_self
on 
(
analytics_area_all_positions_pts_prediction.id_player = analytics_area_all_positions_pts_acc_to_self.id_player and
analytics_area_all_positions_pts_prediction.week = analytics_area_all_positions_pts_acc_to_self.week 
)
left join
pool_area_all_positions_by_week
on
(
analytics_area_all_positions_pts_prediction.id_player = pool_area_all_positions_by_week.id_player and
analytics_area_all_positions_pts_prediction.week = pool_area_all_positions_by_week.week 
)
) a
) a 
join (select * from pool_area_rosters where roster_id = @p_roster_id) pool_area_rosters
on (pool_area_rosters.player_id = a.id_player and pool_area_rosters.week+1 = a.week)
);

drop FUNCTION if exists f_GetPlayerPredictionsWeek;
CREATE FUNCTION f_GetPlayerPredictionsWeek (@p_week INT)
RETURNS TABLE
AS
RETURN
(
select distinct
a.player,a.position,a.team,a.week,a.pts_final,a.floor_final,a.ceiling_final,a.pts_actual,a.pct_error,a.is_miss,a.pts_all,a.floor_all,a.ceiling_all,a.pts_l3,a.floor_l3,a.ceiling_l3,a.pts_acc_to_self,a.pts_acc_to_opponent
from (
select 
id_player,
player,	
position,
team,
week,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_final,1)
when position in ('QB') THEN ROUND(pts_final,2)
when position in ('DST','K') THEN ROUND(pts_final,0)
END pts_final,
case 
when position in ('WR','TE','RB') THEN ROUND(floor_final,1)
when position in ('QB') THEN ROUND(floor_final,2)
when position in ('DST','K') THEN ROUND(floor_final,0)
END floor_final,
case 
when position in ('WR','TE','RB') THEN ROUND(ceiling_final,1)
when position in ('QB') THEN ROUND(ceiling_final,2)
when position in ('DST','K') THEN ROUND(ceiling_final,0)
END ceiling_final,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_actual,1)
when position in ('QB') THEN ROUND(pts_actual,2)
when position in ('DST','K') THEN ROUND(pts_actual,0)
END pts_actual,
pct_error,
is_miss,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_all,1)
when position in ('QB') THEN ROUND(pts_all,2)
when position in ('DST','K') THEN ROUND(pts_all,0)
END pts_all,
case 
when position in ('WR','TE','RB') THEN ROUND(floor_all,1)
when position in ('QB') THEN ROUND(floor_all,2)
when position in ('DST','K') THEN ROUND(floor_all,0)
END floor_all,
case 
when position in ('WR','TE','RB') THEN ROUND(ceiling_all,1)
when position in ('QB') THEN ROUND(ceiling_all,2)
when position in ('DST','K') THEN ROUND(ceiling_all,0)
END ceiling_all,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_l3,1)
when position in ('QB') THEN ROUND(pts_l3,2)
when position in ('DST','K') THEN ROUND(pts_l3,0)
END pts_l3,
case 
when position in ('WR','TE','RB') THEN ROUND(floor_l3,1)
when position in ('QB') THEN ROUND(floor_l3,2)
when position in ('DST','K') THEN ROUND(floor_l3,0)
END floor_l3,
case 
when position in ('WR','TE','RB') THEN ROUND(ceiling_l3,1)
when position in ('QB') THEN ROUND(ceiling_l3,2)
when position in ('DST','K') THEN ROUND(ceiling_l3,0)
END ceiling_l3,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_acc_to_self,1)
when position in ('QB') THEN ROUND(pts_acc_to_self,2)
when position in ('DST','K') THEN ROUND(pts_acc_to_self,0)
END pts_acc_to_self,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_acc_to_opponent,1)
when position in ('QB') THEN ROUND(pts_acc_to_opponent,2)
when position in ('DST','K') THEN ROUND(pts_acc_to_opponent,0)
END pts_acc_to_opponent
from 
(
select analytics_area_all_positions_pts_prediction.id_player, analytics_area_all_positions_pts_prediction.player,analytics_area_all_positions_pts_prediction.position, analytics_area_all_positions_pts_prediction.team, analytics_area_all_positions_pts_prediction.week, 
(analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2 pts_final,
(isnull(analytics_area_all_positions_pts_prediction.floor,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.floor,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2 floor_final,
(isnull(analytics_area_all_positions_pts_prediction.ceiling,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.ceiling,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2 ceiling_final,
pool_area_all_positions_by_week.pts pts_actual,
case 
when ((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2) <> 0
then abs(((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2)-pool_area_all_positions_by_week.pts)
     /
	 ((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2)*100 
when pool_area_all_positions_by_week.pts <> 0
then abs(((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2)-pool_area_all_positions_by_week.pts)
     /
	 pool_area_all_positions_by_week.pts*100  
else null 
end pct_error,
case 
when pool_area_all_positions_by_week.pts between (isnull(analytics_area_all_positions_pts_prediction.floor,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.floor,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2 and (isnull(analytics_area_all_positions_pts_prediction.ceiling,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.ceiling,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2
then 'NO'
WHEN pool_area_all_positions_by_week.pts IS NULL
THEN NULL
ELSE 'YES'
END is_miss,
analytics_area_all_positions_pts_prediction.pts pts_all, 
isnull(analytics_area_all_positions_pts_prediction.floor,analytics_area_all_positions_pts_prediction.pts) floor_all, 
isnull(analytics_area_all_positions_pts_prediction.ceiling,analytics_area_all_positions_pts_prediction.pts) ceiling_all,
analytics_area_all_positions_pts_prediction_last_3_week.pts pts_l3, 
isnull(analytics_area_all_positions_pts_prediction_last_3_week.floor,analytics_area_all_positions_pts_prediction_last_3_week.pts) floor_l3, 
isnull(analytics_area_all_positions_pts_prediction_last_3_week.ceiling,analytics_area_all_positions_pts_prediction_last_3_week.pts) ceiling_l3,
analytics_area_all_positions_pts_acc_to_self.pts pts_acc_to_self,
analytics_area_all_positions_pts_acc_to_opponent.pts pts_acc_to_opponent
from  (select * from analytics_area_all_positions_pts_prediction where week = @p_week+1) analytics_area_all_positions_pts_prediction join 
analytics_area_all_positions_pts_prediction_last_3_week
on  
(
analytics_area_all_positions_pts_prediction.id_player = analytics_area_all_positions_pts_prediction_last_3_week.id_player and
analytics_area_all_positions_pts_prediction.week = analytics_area_all_positions_pts_prediction_last_3_week.week 
)
join
analytics_area_all_positions_pts_acc_to_opponent
on 
(
analytics_area_all_positions_pts_prediction.id_player = analytics_area_all_positions_pts_acc_to_opponent.id_player and
analytics_area_all_positions_pts_prediction.week = analytics_area_all_positions_pts_acc_to_opponent.week 
)
join
analytics_area_all_positions_pts_acc_to_self
on 
(
analytics_area_all_positions_pts_prediction.id_player = analytics_area_all_positions_pts_acc_to_self.id_player and
analytics_area_all_positions_pts_prediction.week = analytics_area_all_positions_pts_acc_to_self.week 
)
left join
pool_area_all_positions_by_week
on
(
analytics_area_all_positions_pts_prediction.id_player = pool_area_all_positions_by_week.id_player and
analytics_area_all_positions_pts_prediction.week = pool_area_all_positions_by_week.week 
)
) a
) a 
);

drop FUNCTION if exists f_GetPlayerPredictions;
CREATE FUNCTION f_GetPlayerPredictions()
RETURNS TABLE
AS
RETURN
(
select distinct
a.player,a.position,a.team,a.week,a.pts_final,a.floor_final,a.ceiling_final,a.pts_actual,a.pct_error,a.is_miss,a.pts_all,a.floor_all,a.ceiling_all,a.pts_l3,a.floor_l3,a.ceiling_l3,a.pts_acc_to_self,a.pts_acc_to_opponent
from (
select 
id_player,
player,	
position,
team,
week,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_final,1)
when position in ('QB') THEN ROUND(pts_final,2)
when position in ('DST','K') THEN ROUND(pts_final,0)
END pts_final,
case 
when position in ('WR','TE','RB') THEN ROUND(floor_final,1)
when position in ('QB') THEN ROUND(floor_final,2)
when position in ('DST','K') THEN ROUND(floor_final,0)
END floor_final,
case 
when position in ('WR','TE','RB') THEN ROUND(ceiling_final,1)
when position in ('QB') THEN ROUND(ceiling_final,2)
when position in ('DST','K') THEN ROUND(ceiling_final,0)
END ceiling_final,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_actual,1)
when position in ('QB') THEN ROUND(pts_actual,2)
when position in ('DST','K') THEN ROUND(pts_actual,0)
END pts_actual,
pct_error,
is_miss,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_all,1)
when position in ('QB') THEN ROUND(pts_all,2)
when position in ('DST','K') THEN ROUND(pts_all,0)
END pts_all,
case 
when position in ('WR','TE','RB') THEN ROUND(floor_all,1)
when position in ('QB') THEN ROUND(floor_all,2)
when position in ('DST','K') THEN ROUND(floor_all,0)
END floor_all,
case 
when position in ('WR','TE','RB') THEN ROUND(ceiling_all,1)
when position in ('QB') THEN ROUND(ceiling_all,2)
when position in ('DST','K') THEN ROUND(ceiling_all,0)
END ceiling_all,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_l3,1)
when position in ('QB') THEN ROUND(pts_l3,2)
when position in ('DST','K') THEN ROUND(pts_l3,0)
END pts_l3,
case 
when position in ('WR','TE','RB') THEN ROUND(floor_l3,1)
when position in ('QB') THEN ROUND(floor_l3,2)
when position in ('DST','K') THEN ROUND(floor_l3,0)
END floor_l3,
case 
when position in ('WR','TE','RB') THEN ROUND(ceiling_l3,1)
when position in ('QB') THEN ROUND(ceiling_l3,2)
when position in ('DST','K') THEN ROUND(ceiling_l3,0)
END ceiling_l3,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_acc_to_self,1)
when position in ('QB') THEN ROUND(pts_acc_to_self,2)
when position in ('DST','K') THEN ROUND(pts_acc_to_self,0)
END pts_acc_to_self,
case 
when position in ('WR','TE','RB') THEN ROUND(pts_acc_to_opponent,1)
when position in ('QB') THEN ROUND(pts_acc_to_opponent,2)
when position in ('DST','K') THEN ROUND(pts_acc_to_opponent,0)
END pts_acc_to_opponent
from 
(
select analytics_area_all_positions_pts_prediction.id_player, analytics_area_all_positions_pts_prediction.player,analytics_area_all_positions_pts_prediction.position, analytics_area_all_positions_pts_prediction.team, analytics_area_all_positions_pts_prediction.week, 
(analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2 pts_final,
(isnull(analytics_area_all_positions_pts_prediction.floor,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.floor,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2 floor_final,
(isnull(analytics_area_all_positions_pts_prediction.ceiling,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.ceiling,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2 ceiling_final,
pool_area_all_positions_by_week.pts pts_actual,
case 
when ((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2) <> 0
then abs(((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2)-pool_area_all_positions_by_week.pts)
     /
	 ((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2)*100 
when pool_area_all_positions_by_week.pts <> 0
then abs(((analytics_area_all_positions_pts_prediction.pts+analytics_area_all_positions_pts_prediction_last_3_week.pts)/2)-pool_area_all_positions_by_week.pts)
     /
	 pool_area_all_positions_by_week.pts*100  
else null 
end pct_error,
case 
when pool_area_all_positions_by_week.pts between (isnull(analytics_area_all_positions_pts_prediction.floor,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.floor,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2 and (isnull(analytics_area_all_positions_pts_prediction.ceiling,analytics_area_all_positions_pts_prediction.pts)+isnull(analytics_area_all_positions_pts_prediction_last_3_week.ceiling,analytics_area_all_positions_pts_prediction_last_3_week.pts))/ 2
then 'NO'
WHEN pool_area_all_positions_by_week.pts IS NULL
THEN NULL
ELSE 'YES'
END is_miss,
analytics_area_all_positions_pts_prediction.pts pts_all, 
isnull(analytics_area_all_positions_pts_prediction.floor,analytics_area_all_positions_pts_prediction.pts) floor_all, 
isnull(analytics_area_all_positions_pts_prediction.ceiling,analytics_area_all_positions_pts_prediction.pts) ceiling_all,
analytics_area_all_positions_pts_prediction_last_3_week.pts pts_l3, 
isnull(analytics_area_all_positions_pts_prediction_last_3_week.floor,analytics_area_all_positions_pts_prediction_last_3_week.pts) floor_l3, 
isnull(analytics_area_all_positions_pts_prediction_last_3_week.ceiling,analytics_area_all_positions_pts_prediction_last_3_week.pts) ceiling_l3,
analytics_area_all_positions_pts_acc_to_self.pts pts_acc_to_self,
analytics_area_all_positions_pts_acc_to_opponent.pts pts_acc_to_opponent
from  analytics_area_all_positions_pts_prediction analytics_area_all_positions_pts_prediction join 
analytics_area_all_positions_pts_prediction_last_3_week
on  
(
analytics_area_all_positions_pts_prediction.id_player = analytics_area_all_positions_pts_prediction_last_3_week.id_player and
analytics_area_all_positions_pts_prediction.week = analytics_area_all_positions_pts_prediction_last_3_week.week 
)
join
analytics_area_all_positions_pts_acc_to_opponent
on 
(
analytics_area_all_positions_pts_prediction.id_player = analytics_area_all_positions_pts_acc_to_opponent.id_player and
analytics_area_all_positions_pts_prediction.week = analytics_area_all_positions_pts_acc_to_opponent.week 
)
join
analytics_area_all_positions_pts_acc_to_self
on 
(
analytics_area_all_positions_pts_prediction.id_player = analytics_area_all_positions_pts_acc_to_self.id_player and
analytics_area_all_positions_pts_prediction.week = analytics_area_all_positions_pts_acc_to_self.week 
)
left join
pool_area_all_positions_by_week
on
(
analytics_area_all_positions_pts_prediction.id_player = pool_area_all_positions_by_week.id_player and
analytics_area_all_positions_pts_prediction.week = pool_area_all_positions_by_week.week 
)
) a
) a 
);

