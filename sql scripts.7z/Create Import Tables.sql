USE [fantasy]
GO
/****** Object:  Table [dbo].[import_area_DST]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_DST](
	[Player] [nvarchar](100) NULL,
	[Game] [nvarchar](7) NULL,
	[Pts] [numeric](18, 0) NULL,
	[Sack] [numeric](18, 0) NULL,
	[Int] [int] NULL,
	[Saf] [int] NULL,
	[FR] [int] NULL,
	[Blk] [int] NULL,
	[TD] [int] NULL,
	[PA] [int] NULL,
	[PassYds] [int] NULL,
	[RushYds] [int] NULL,
	[TotYds] [int] NULL,
	[Bolded Game Info] [nvarchar](7) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[import_area_footballdb_sleeper_fix]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_footballdb_sleeper_fix](
	[footballdb_player] [nvarchar](100) NULL,
	[footballdb_team] [nvarchar](3) NULL,
	[footballdb_position] [nvarchar](3) NULL,
	[sleeper_Player_id] [nvarchar](10) NULL,
	[sleeper_player] [nvarchar](100) NULL,
	[sleeper_team] [nvarchar](3) NULL,
	[sleeper_position] [nvarchar](3) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[import_area_K]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_K](
	[Player] [nvarchar](100) NULL,
	[Game] [nvarchar](7) NULL,
	[Pts] [numeric](18, 0) NULL,
	[XPA] [int] NULL,
	[XPM] [int] NULL,
	[FGA] [int] NULL,
	[FGM] [int] NULL,
	[50+] [int] NULL,
	[Bolded Game Info] [nvarchar](7) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[import_area_QB]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_QB](
	[Player] [nvarchar](100) NULL,
	[Game] [nvarchar](7) NULL,
	[Pts*] [numeric](18, 0) NULL,
	[PassAtt] [int] NULL,
	[PassCmp] [int] NULL,
	[PassYds] [int] NULL,
	[PassTD] [int] NULL,
	[PassInt] [int] NULL,
	[Pass2Pt] [int] NULL,
	[RushAtt] [int] NULL,
	[RushYds] [int] NULL,
	[RushTD] [int] NULL,
	[Rush2Pt] [int] NULL,
	[RecRec] [int] NULL,
	[RecYds] [int] NULL,
	[RecTD] [int] NULL,
	[Rec2Pt] [int] NULL,
	[FumFL] [int] NULL,
	[FumTD] [int] NULL,
	[Bolded Game Info] [nvarchar](7) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[import_area_RB]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_RB](
	[Player] [nvarchar](100) NULL,
	[Game] [nvarchar](7) NULL,
	[Pts*] [numeric](18, 0) NULL,
	[PassAtt] [int] NULL,
	[PassCmp] [int] NULL,
	[PassYds] [int] NULL,
	[PassTD] [int] NULL,
	[PassInt] [int] NULL,
	[Pass2Pt] [int] NULL,
	[RushAtt] [int] NULL,
	[RushYds] [int] NULL,
	[RushTD] [int] NULL,
	[Rush2Pt] [int] NULL,
	[RecRec] [int] NULL,
	[RecYds] [int] NULL,
	[RecTD] [int] NULL,
	[Rec2Pt] [int] NULL,
	[FumFL] [int] NULL,
	[FumTD] [int] NULL,
	[Bolded Game Info] [nvarchar](7) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[import_area_rosters]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_rosters](
	[Roster_id] [int] NULL,
	[Player_id] [nvarchar](10) NULL,
	[player_name] [nvarchar](100) NULL,
	[team] [nvarchar](3) NULL,
	[position] [nvarchar](3) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[import_area_schedule]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_schedule](
	[Date] [nvarchar](100) NULL,
	[Visitor] [nvarchar](100) NULL,
	[Visitor Score] [int] NULL,
	[Home] [nvarchar](100) NULL,
	[Home Score] [int] NULL,
	[Location] [nvarchar](100) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[import_area_sleeper_player]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_sleeper_player](
	[Player_id] [nvarchar](10) NULL,
	[name] [nvarchar](100) NULL,
	[team] [nvarchar](3) NULL,
	[position] [nvarchar](3) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[import_area_TE]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_TE](
	[Player] [nvarchar](100) NULL,
	[Game] [nvarchar](7) NULL,
	[Pts*] [numeric](18, 0) NULL,
	[PassAtt] [int] NULL,
	[PassCmp] [int] NULL,
	[PassYds] [int] NULL,
	[PassTD] [int] NULL,
	[PassInt] [int] NULL,
	[Pass2Pt] [int] NULL,
	[RushAtt] [int] NULL,
	[RushYds] [int] NULL,
	[RushTD] [int] NULL,
	[Rush2Pt] [int] NULL,
	[RecRec] [int] NULL,
	[RecYds] [int] NULL,
	[RecTD] [int] NULL,
	[Rec2Pt] [int] NULL,
	[FumFL] [int] NULL,
	[FumTD] [int] NULL,
	[Bolded Game Info] [nvarchar](7) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[import_area_trades]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_trades](
	[sleeper_Player_id] [nvarchar](10) NULL,
	[sleeper_player] [nvarchar](100) NULL,
	[footballdb_player] [nvarchar](100) NULL,
	[leaving_team] [nvarchar](3) NULL,
	[arriving_team] [nvarchar](3) NULL,
	[footballdb_position] [nvarchar](3) NULL,
	[week] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[import_area_WR]    Script Date: 7.12.2024. 18:55:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[import_area_WR](
	[Player] [nvarchar](100) NULL,
	[Game] [nvarchar](7) NULL,
	[Pts*] [numeric](18, 0) NULL,
	[PassAtt] [int] NULL,
	[PassCmp] [int] NULL,
	[PassYds] [int] NULL,
	[PassTD] [int] NULL,
	[PassInt] [int] NULL,
	[Pass2Pt] [int] NULL,
	[RushAtt] [int] NULL,
	[RushYds] [int] NULL,
	[RushTD] [int] NULL,
	[Rush2Pt] [int] NULL,
	[RecRec] [int] NULL,
	[RecYds] [int] NULL,
	[RecTD] [int] NULL,
	[Rec2Pt] [int] NULL,
	[FumFL] [int] NULL,
	[FumTD] [int] NULL,
	[Bolded Game Info] [nvarchar](7) NULL
) ON [PRIMARY]
GO
