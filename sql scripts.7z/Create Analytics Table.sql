USE [fantasy]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_opponent_prev_median]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_opponent_prev_median](
	[position] [nvarchar](3) NULL,
	[opponent] [nvarchar](7) NULL,
	[week] [int] NOT NULL,
	[median_pts] [float] NULL,
	[median_PassAtt] [float] NULL,
	[median_PassCmp] [float] NULL,
	[median_PassYds] [float] NULL,
	[median_PassTD] [float] NULL,
	[median_PassInt] [float] NULL,
	[median_Pass2Pt] [float] NULL,
	[median_RushAtt] [float] NULL,
	[median_RushYds] [float] NULL,
	[median_RushTD] [float] NULL,
	[median_Rush2Pt] [float] NULL,
	[median_RecRec] [float] NULL,
	[median_RecYds] [float] NULL,
	[median_RecTD] [float] NULL,
	[median_Rec2Pt] [float] NULL,
	[median_FumFL] [float] NULL,
	[median_FumTD] [float] NULL,
	[median_XPA] [float] NULL,
	[median_XPM] [float] NULL,
	[median_FGA] [float] NULL,
	[median_FGM] [float] NULL,
	[median_50+] [float] NULL,
	[median_Sack] [float] NULL,
	[median_Int] [float] NULL,
	[median_Saf] [float] NULL,
	[median_FR] [float] NULL,
	[median_Blk] [float] NULL,
	[median_TD] [float] NULL,
	[median_PA] [float] NULL,
	[median_PassYdsDST] [float] NULL,
	[median_RushYdsDST] [float] NULL,
	[median_TotYdsDST] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_opponent_prev_median_last_3_week]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_opponent_prev_median_last_3_week](
	[position] [nvarchar](3) NULL,
	[opponent] [nvarchar](7) NULL,
	[week] [int] NOT NULL,
	[median_pts] [float] NULL,
	[median_PassAtt] [float] NULL,
	[median_PassCmp] [float] NULL,
	[median_PassYds] [float] NULL,
	[median_PassTD] [float] NULL,
	[median_PassInt] [float] NULL,
	[median_Pass2Pt] [float] NULL,
	[median_RushAtt] [float] NULL,
	[median_RushYds] [float] NULL,
	[median_RushTD] [float] NULL,
	[median_Rush2Pt] [float] NULL,
	[median_RecRec] [float] NULL,
	[median_RecYds] [float] NULL,
	[median_RecTD] [float] NULL,
	[median_Rec2Pt] [float] NULL,
	[median_FumFL] [float] NULL,
	[median_FumTD] [float] NULL,
	[median_XPA] [float] NULL,
	[median_XPM] [float] NULL,
	[median_FGA] [float] NULL,
	[median_FGM] [float] NULL,
	[median_50+] [float] NULL,
	[median_Sack] [float] NULL,
	[median_Int] [float] NULL,
	[median_Saf] [float] NULL,
	[median_FR] [float] NULL,
	[median_Blk] [float] NULL,
	[median_TD] [float] NULL,
	[median_PA] [float] NULL,
	[median_PassYdsDST] [float] NULL,
	[median_RushYdsDST] [float] NULL,
	[median_TotYdsDST] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_prev_median]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_prev_median](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[team] [nvarchar](7) NULL,
	[week] [int] NULL,
	[median_pts_pct] [float] NULL,
	[median_pts_PassAtt] [float] NULL,
	[median_pts_PassCmp] [float] NULL,
	[median_pts_PassYds] [float] NULL,
	[median_pts_PassTD] [float] NULL,
	[median_pts_PassInt] [float] NULL,
	[median_pts_Pass2Pt] [float] NULL,
	[median_pts_RushAtt] [float] NULL,
	[median_pts_RushYds] [float] NULL,
	[median_pts_RushTD] [float] NULL,
	[median_pts_Rush2Pt] [float] NULL,
	[median_pts_RecRec] [float] NULL,
	[median_pts_RecYds] [float] NULL,
	[median_pts_RecTD] [float] NULL,
	[median_pts_Rec2Pt] [float] NULL,
	[median_pts_FumFL] [float] NULL,
	[median_pts_FumTD] [float] NULL,
	[median_pts_XPA] [float] NULL,
	[median_pts_XPM] [float] NULL,
	[median_pts_FGA] [float] NULL,
	[median_pts_FGM] [float] NULL,
	[median_pts_50+] [float] NULL,
	[median_pts_Sack] [float] NULL,
	[median_pts_Int] [float] NULL,
	[median_pts_Saf] [float] NULL,
	[median_pts_FR] [float] NULL,
	[median_pts_Blk] [float] NULL,
	[median_pts_TD] [float] NULL,
	[median_pts_PA] [float] NULL,
	[median_pts_PassYdsDST] [float] NULL,
	[median_pts_RushYdsDST] [float] NULL,
	[median_pts_TotYdsDST] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_prev_median_last_3_week]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_prev_median_last_3_week](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[team] [nvarchar](7) NULL,
	[week] [int] NULL,
	[median_pts_pct] [float] NULL,
	[median_pts_PassAtt] [float] NULL,
	[median_pts_PassCmp] [float] NULL,
	[median_pts_PassYds] [float] NULL,
	[median_pts_PassTD] [float] NULL,
	[median_pts_PassInt] [float] NULL,
	[median_pts_Pass2Pt] [float] NULL,
	[median_pts_RushAtt] [float] NULL,
	[median_pts_RushYds] [float] NULL,
	[median_pts_RushTD] [float] NULL,
	[median_pts_Rush2Pt] [float] NULL,
	[median_pts_RecRec] [float] NULL,
	[median_pts_RecYds] [float] NULL,
	[median_pts_RecTD] [float] NULL,
	[median_pts_Rec2Pt] [float] NULL,
	[median_pts_FumFL] [float] NULL,
	[median_pts_FumTD] [float] NULL,
	[median_pts_XPA] [float] NULL,
	[median_pts_XPM] [float] NULL,
	[median_pts_FGA] [float] NULL,
	[median_pts_FGM] [float] NULL,
	[median_pts_50+] [float] NULL,
	[median_pts_Sack] [float] NULL,
	[median_pts_Int] [float] NULL,
	[median_pts_Saf] [float] NULL,
	[median_pts_FR] [float] NULL,
	[median_pts_Blk] [float] NULL,
	[median_pts_TD] [float] NULL,
	[median_pts_PA] [float] NULL,
	[median_pts_PassYdsDST] [float] NULL,
	[median_pts_RushYdsDST] [float] NULL,
	[median_pts_TotYdsDST] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_prev_pct]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_prev_pct](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[team] [nvarchar](7) NULL,
	[week] [int] NULL,
	[pts_pct] [numeric](3, 2) NULL,
	[PassAtt_pct] [numeric](3, 2) NULL,
	[PassCmp_pct] [numeric](3, 2) NULL,
	[PassYds_pct] [numeric](3, 2) NULL,
	[PassTD_pct] [numeric](3, 2) NULL,
	[PassInt_pct] [numeric](3, 2) NULL,
	[Pass2Pt_pct] [numeric](3, 2) NULL,
	[RushAtt_pct] [numeric](3, 2) NULL,
	[RushYds_pct] [numeric](3, 2) NULL,
	[RushTD_pct] [numeric](3, 2) NULL,
	[Rush2Pt_pct] [numeric](3, 2) NULL,
	[RecRec_pct] [numeric](3, 2) NULL,
	[RecYds_pct] [numeric](3, 2) NULL,
	[RecTD_pct] [numeric](3, 2) NULL,
	[Rec2Pt_pct] [numeric](3, 2) NULL,
	[FumFL_pct] [numeric](3, 2) NULL,
	[FumTD_pct] [numeric](3, 2) NULL,
	[XPA_pct] [numeric](3, 2) NULL,
	[XPM_pct] [numeric](3, 2) NULL,
	[FGA_pct] [numeric](3, 2) NULL,
	[FGM_pct] [numeric](3, 2) NULL,
	[50+_pct] [numeric](3, 2) NULL,
	[Sack_pct] [numeric](3, 2) NULL,
	[Int_pct] [numeric](3, 2) NULL,
	[Saf_pct] [numeric](3, 2) NULL,
	[FR_pct] [numeric](3, 2) NULL,
	[Blk_pct] [numeric](3, 2) NULL,
	[TD_pct] [numeric](3, 2) NULL,
	[PA_pct] [numeric](3, 2) NULL,
	[PassYdsDST_pct] [numeric](3, 2) NULL,
	[RushYdsDST_pct] [numeric](3, 2) NULL,
	[TotYdsDST_pct] [numeric](3, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_prev_pct_median]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_prev_pct_median](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[week] [int] NOT NULL,
	[median_pts_pct] [float] NULL,
	[median_PassAtt_pct] [float] NULL,
	[median_PassCmp_pct] [float] NULL,
	[median_PassYds_pct] [float] NULL,
	[median_PassTD_pct] [float] NULL,
	[median_PassInt_pct] [float] NULL,
	[median_Pass2Pt_pct] [float] NULL,
	[median_RushAtt_pct] [float] NULL,
	[median_RushYds_pct] [float] NULL,
	[median_RushTD_pct] [float] NULL,
	[median_Rush2Pt_pct] [float] NULL,
	[median_RecRec_pct] [float] NULL,
	[median_RecYds_pct] [float] NULL,
	[median_RecTD_pct] [float] NULL,
	[median_Rec2Pt_pct] [float] NULL,
	[median_FumFL_pct] [float] NULL,
	[median_FumTD_pct] [float] NULL,
	[median_XPA_pct] [float] NULL,
	[median_XPM_pct] [float] NULL,
	[median_FGA_pct] [float] NULL,
	[median_FGM_pct] [float] NULL,
	[median_50+_pct] [float] NULL,
	[median_Sack_pct] [float] NULL,
	[median_Int_pct] [float] NULL,
	[median_Saf_pct] [float] NULL,
	[median_FR_pct] [float] NULL,
	[median_Blk_pct] [float] NULL,
	[median_TD_pct] [float] NULL,
	[median_PA_pct] [float] NULL,
	[median_PassYdsDST_pct] [float] NULL,
	[median_RushYdsDST_pct] [float] NULL,
	[median_TotYdsDST_pct] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_prev_pct_median_last_3_week]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_prev_pct_median_last_3_week](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[week] [int] NOT NULL,
	[median_pts_pct] [float] NULL,
	[median_PassAtt_pct] [float] NULL,
	[median_PassCmp_pct] [float] NULL,
	[median_PassYds_pct] [float] NULL,
	[median_PassTD_pct] [float] NULL,
	[median_PassInt_pct] [float] NULL,
	[median_Pass2Pt_pct] [float] NULL,
	[median_RushAtt_pct] [float] NULL,
	[median_RushYds_pct] [float] NULL,
	[median_RushTD_pct] [float] NULL,
	[median_Rush2Pt_pct] [float] NULL,
	[median_RecRec_pct] [float] NULL,
	[median_RecYds_pct] [float] NULL,
	[median_RecTD_pct] [float] NULL,
	[median_Rec2Pt_pct] [float] NULL,
	[median_FumFL_pct] [float] NULL,
	[median_FumTD_pct] [float] NULL,
	[median_XPA_pct] [float] NULL,
	[median_XPM_pct] [float] NULL,
	[median_FGA_pct] [float] NULL,
	[median_FGM_pct] [float] NULL,
	[median_50+_pct] [float] NULL,
	[median_Sack_pct] [float] NULL,
	[median_Int_pct] [float] NULL,
	[median_Saf_pct] [float] NULL,
	[median_FR_pct] [float] NULL,
	[median_Blk_pct] [float] NULL,
	[median_TD_pct] [float] NULL,
	[median_PA_pct] [float] NULL,
	[median_PassYdsDST_pct] [float] NULL,
	[median_RushYdsDST_pct] [float] NULL,
	[median_TotYdsDST_pct] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_pts_acc_to_opponent]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_pts_acc_to_opponent](
	[id_Player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[week] [int] NOT NULL,
	[median_pts] [float] NULL,
	[median_PassAtt] [float] NULL,
	[median_PassCmp] [float] NULL,
	[median_PassYds] [float] NULL,
	[median_PassTD] [float] NULL,
	[median_PassInt] [float] NULL,
	[median_Pass2Pt] [float] NULL,
	[median_RushAtt] [float] NULL,
	[median_RushYds] [float] NULL,
	[median_RushTD] [float] NULL,
	[median_Rush2Pt] [float] NULL,
	[median_RecRec] [float] NULL,
	[median_RecYds] [float] NULL,
	[median_RecTD] [float] NULL,
	[median_Rec2Pt] [float] NULL,
	[median_FumFL] [float] NULL,
	[median_FumTD] [float] NULL,
	[median_XPA] [float] NULL,
	[median_XPM] [float] NULL,
	[median_FGA] [float] NULL,
	[median_FGM] [float] NULL,
	[median_50+] [float] NULL,
	[median_Sack] [float] NULL,
	[median_Int] [float] NULL,
	[median_Saf] [float] NULL,
	[median_FR] [float] NULL,
	[median_Blk] [float] NULL,
	[median_TD] [float] NULL,
	[median_PA] [float] NULL,
	[median_PassYdsDST] [float] NULL,
	[median_RushYdsDST] [float] NULL,
	[median_TotYdsDST] [float] NULL,
	[pts_calc] [float] NULL,
	[pts] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_pts_acc_to_opponent_last_3_Week]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_pts_acc_to_opponent_last_3_Week](
	[id_Player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[week] [int] NOT NULL,
	[median_pts] [float] NULL,
	[median_PassAtt] [float] NULL,
	[median_PassCmp] [float] NULL,
	[median_PassYds] [float] NULL,
	[median_PassTD] [float] NULL,
	[median_PassInt] [float] NULL,
	[median_Pass2Pt] [float] NULL,
	[median_RushAtt] [float] NULL,
	[median_RushYds] [float] NULL,
	[median_RushTD] [float] NULL,
	[median_Rush2Pt] [float] NULL,
	[median_RecRec] [float] NULL,
	[median_RecYds] [float] NULL,
	[median_RecTD] [float] NULL,
	[median_Rec2Pt] [float] NULL,
	[median_FumFL] [float] NULL,
	[median_FumTD] [float] NULL,
	[median_XPA] [float] NULL,
	[median_XPM] [float] NULL,
	[median_FGA] [float] NULL,
	[median_FGM] [float] NULL,
	[median_50+] [float] NULL,
	[median_Sack] [float] NULL,
	[median_Int] [float] NULL,
	[median_Saf] [float] NULL,
	[median_FR] [float] NULL,
	[median_Blk] [float] NULL,
	[median_TD] [float] NULL,
	[median_PA] [float] NULL,
	[median_PassYdsDST] [float] NULL,
	[median_RushYdsDST] [float] NULL,
	[median_TotYdsDST] [float] NULL,
	[pts_calc] [float] NULL,
	[pts] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_pts_acc_to_self]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_pts_acc_to_self](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[team] [nvarchar](7) NULL,
	[week] [int] NULL,
	[median_pts_pct] [float] NULL,
	[median_pts_PassAtt] [float] NULL,
	[median_pts_PassCmp] [float] NULL,
	[median_pts_PassYds] [float] NULL,
	[median_pts_PassTD] [float] NULL,
	[median_pts_PassInt] [float] NULL,
	[median_pts_Pass2Pt] [float] NULL,
	[median_pts_RushAtt] [float] NULL,
	[median_pts_RushYds] [float] NULL,
	[median_pts_RushTD] [float] NULL,
	[median_pts_Rush2Pt] [float] NULL,
	[median_pts_RecRec] [float] NULL,
	[median_pts_RecYds] [float] NULL,
	[median_pts_RecTD] [float] NULL,
	[median_pts_Rec2Pt] [float] NULL,
	[median_pts_FumFL] [float] NULL,
	[median_pts_FumTD] [float] NULL,
	[median_pts_XPA] [float] NULL,
	[median_pts_XPM] [float] NULL,
	[median_pts_FGA] [float] NULL,
	[median_pts_FGM] [float] NULL,
	[median_pts_50+] [float] NULL,
	[median_pts_Sack] [float] NULL,
	[median_pts_Int] [float] NULL,
	[median_pts_Saf] [float] NULL,
	[median_pts_FR] [float] NULL,
	[median_pts_Blk] [float] NULL,
	[median_pts_TD] [float] NULL,
	[median_pts_PA] [float] NULL,
	[median_pts_PassYdsDST] [float] NULL,
	[median_pts_RushYdsDST] [float] NULL,
	[median_pts_TotYdsDST] [float] NULL,
	[pts_calc] [float] NULL,
	[pts] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_pts_acc_to_self_last_3_Week]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_pts_acc_to_self_last_3_Week](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[team] [nvarchar](7) NULL,
	[week] [int] NULL,
	[median_pts_pct] [float] NULL,
	[median_pts_PassAtt] [float] NULL,
	[median_pts_PassCmp] [float] NULL,
	[median_pts_PassYds] [float] NULL,
	[median_pts_PassTD] [float] NULL,
	[median_pts_PassInt] [float] NULL,
	[median_pts_Pass2Pt] [float] NULL,
	[median_pts_RushAtt] [float] NULL,
	[median_pts_RushYds] [float] NULL,
	[median_pts_RushTD] [float] NULL,
	[median_pts_Rush2Pt] [float] NULL,
	[median_pts_RecRec] [float] NULL,
	[median_pts_RecYds] [float] NULL,
	[median_pts_RecTD] [float] NULL,
	[median_pts_Rec2Pt] [float] NULL,
	[median_pts_FumFL] [float] NULL,
	[median_pts_FumTD] [float] NULL,
	[median_pts_XPA] [float] NULL,
	[median_pts_XPM] [float] NULL,
	[median_pts_FGA] [float] NULL,
	[median_pts_FGM] [float] NULL,
	[median_pts_50+] [float] NULL,
	[median_pts_Sack] [float] NULL,
	[median_pts_Int] [float] NULL,
	[median_pts_Saf] [float] NULL,
	[median_pts_FR] [float] NULL,
	[median_pts_Blk] [float] NULL,
	[median_pts_TD] [float] NULL,
	[median_pts_PA] [float] NULL,
	[median_pts_PassYdsDST] [float] NULL,
	[median_pts_RushYdsDST] [float] NULL,
	[median_pts_TotYdsDST] [float] NULL,
	[pts_calc] [float] NULL,
	[pts] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_pts_deviation]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_pts_deviation](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[team] [nvarchar](7) NULL,
	[week] [int] NULL,
	[pts_predicted] [float] NULL,
	[pts_actual] [numeric](10, 2) NULL,
	[deviation] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_pts_deviation_correction]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_pts_deviation_correction](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[week] [int] NOT NULL,
	[median_deviation] [float] NULL,
	[median_positive_deviation] [float] NULL,
	[median_negative_deviation] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_pts_deviation_correction_last_3_week]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_pts_deviation_correction_last_3_week](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[week] [int] NULL,
	[median_deviation] [float] NULL,
	[median_positive_deviation] [float] NULL,
	[median_negative_deviation] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_pts_deviation_last_3_week]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_pts_deviation_last_3_week](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[team] [nvarchar](7) NULL,
	[week] [int] NULL,
	[pts_predicted] [float] NULL,
	[pts_actual] [numeric](10, 2) NULL,
	[deviation] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_pts_prediction]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_pts_prediction](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[team] [nvarchar](7) NULL,
	[week] [int] NULL,
	[pts] [float] NULL,
	[floor] [float] NULL,
	[ceiling] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_all_positions_pts_prediction_last_3_Week]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_all_positions_pts_prediction_last_3_Week](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[team] [nvarchar](7) NULL,
	[week] [int] NULL,
	[pts] [float] NULL,
	[floor] [float] NULL,
	[ceiling] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_opponent_pts_deviation_correction]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_opponent_pts_deviation_correction](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[week] [int] NULL,
	[median_deviation] [float] NULL,
	[median_positive_deviation] [float] NULL,
	[median_negative_deviation] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_area_opponent_pts_deviation_correction_last_3_week]    Script Date: 7.12.2024. 19:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_area_opponent_pts_deviation_correction_last_3_week](
	[id_player] [nvarchar](10) NULL,
	[player] [nvarchar](100) NULL,
	[position] [nvarchar](3) NULL,
	[week] [int] NULL,
	[median_deviation] [float] NULL,
	[median_positive_deviation] [float] NULL,
	[median_negative_deviation] [float] NULL
) ON [PRIMARY]
GO
