--points
exec p_import_stage_pool_points; --only once
--schedule
exec p_import_stage_pool_schedule; --only once
--import
exec p_import_area;
--stage
exec p_all_players_id_add;
--correct trades
exec p_correct_trades @p_week = 13;
--check
select * from stage_area_all_players_id where id_player is null --expected null, else fix needed
--insert stage
exec p_insert_area_all_by_week;
--insert pool
exec p_insert_pool_by_week @p_week = 13;
--remove double rows that exists due to trash in data
exec p_remove_double_rows;
--insert analitics
exec p_insert_analitics_by_cur_week_for_futu @p_week = 13;

--get your team prediction for week 
select * from f_GetPlayerPredictionsWeekRoster(13,7);
--get every player prediction for week 
select * from f_GetPlayerPredictionsWeek(13);
--get every player prediction for every week 
select * from f_GetPlayerPredictions();

