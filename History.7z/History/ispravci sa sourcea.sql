1. kolo
update import_area_wr set [Bolded Game Info] = 'CLE' where player like 'Amari Cooper%'
update import_area_RB set [Bolded Game Info] = 'CHI' where player like 'Khalil Herbert%'
update import_area_RB set [Bolded Game Info] = 'HOU' where player like 'Cam Akers%'
update import_area_wr set [Bolded Game Info] = 'BUF' where player like 'Marquez Valdes-Scantling%'

2. kolo
update import_area_wr set [Bolded Game Info] = 'CAR' where player like 'Diontae Johnson%'
update import_area_wr set [Bolded Game Info] = 'CAR' where player like 'Jonathan Mingo%'
update import_area_wr set [Bolded Game Info] = 'TEN' where player like 'DeAndre Hopkins%'
update import_area_wr set [Bolded Game Info] = 'CLE' where player like 'Amari Cooper%'
update import_area_RB set [Bolded Game Info] = 'CHI' where player like 'Khalil Herbert%'
update import_area_RB set [Bolded Game Info] = 'HOU' where player like 'Cam Akers%'
update import_area_wr set [Bolded Game Info] = 'BUF' where player like 'Marquez Valdes-Scantling%'

3.KOLO
update import_area_wr set [Bolded Game Info] = 'CAR' where player like 'Diontae Johnson%'
update import_area_wr set [Bolded Game Info] = 'CAR' where player like 'Jonathan Mingo%'
update import_area_wr set [Bolded Game Info] = 'TEN' where player like 'DeAndre Hopkins%'
update import_area_wr set [Bolded Game Info] = 'CLE' where player like 'Amari Cooper%'
update import_area_RB set [Bolded Game Info] = 'CHI' where player like 'Khalil Herbert%'
update import_area_RB set [Bolded Game Info] = 'HOU' where player like 'Cam Akers%'
update import_area_wr set [Bolded Game Info] = 'LV' where player like 'Davante Adams%'
update import_area_wr set [Bolded Game Info] = 'BUF' where player like 'Marquez Valdes-Scantling%'
update import_area_wr set [Bolded Game Info] = 'NYJ' where player like 'Mike Williams%'

4.KOLO
update import_area_wr set [Bolded Game Info] = 'CAR' where player like 'Diontae Johnson%'
update import_area_wr set [Bolded Game Info] = 'CAR' where player like 'Jonathan Mingo%'
--update import_area_wr set [Bolded Game Info] = 'TEN' where player like 'DeAndre Hopkins%'
--update import_area_wr set [Bolded Game Info] = 'CLE' where player like 'Amari Cooper%'
--update import_area_RB set [Bolded Game Info] = 'CHI' where player like 'Khalil Herbert%'
update import_area_RB set [Bolded Game Info] = 'HOU' where player like 'Cam Akers%'
--update import_area_wr set [Bolded Game Info] = 'LV' where player like 'Davante Adams%'
--update import_area_wr set [Bolded Game Info] = 'BUF' where player like 'Marquez Valdes-Scantling%'
update import_area_wr set [Bolded Game Info] = 'NYJ' where player like 'Mike Williams%'

5.KOLO
update import_area_wr set [Bolded Game Info] = 'CAR' where player like 'Diontae Johnson%'
update import_area_wr set [Bolded Game Info] = 'CAR' where player like 'Jonathan Mingo%'
update import_area_wr set [Bolded Game Info] = 'TEN' where player like 'DeAndre Hopkins%'
--update import_area_wr set [Bolded Game Info] = 'CLE' where player like 'Amari Cooper%'
--update import_area_RB set [Bolded Game Info] = 'CHI' where player like 'Khalil Herbert%'
--update import_area_RB set [Bolded Game Info] = 'HOU' where player like 'Cam Akers%'
--update import_area_wr set [Bolded Game Info] = 'LV' where player like 'Davante Adams%'
--update import_area_wr set [Bolded Game Info] = 'BUF' where player like 'Marquez Valdes-Scantling%'
--update import_area_wr set [Bolded Game Info] = 'NYJ' where player like 'Mike Williams%'

7.KOLO
update import_area_wr set [Bolded Game Info] = 'CLE' where player like 'Amari Cooper%'
update import_area_wr set [Bolded Game Info] = 'NE' where player like 'Tyquan Thornton%'
update import_area_K set [Bolded Game Info] = 'SF' where player like 'Anders Carlson%'
update import_area_K set [Bolded Game Info] = 'KC' where player like 'Spencer Shrader%'
delete from stage_area_all_players_id where player like 'Amari Cooper' and team = 'BUF'
SELECT * FROM stage_area_all_players_id where player like 'Tyquan Thornton'
SELECT * FROM stage_area_all_players_id where player like 'Cam Akers'
SELECT * FROM stage_area_all_players_id where player like 'Davante Adams'
SELECT * FROM stage_area_all_players_id where player like 'Marquez Valdes-Scantling'
SELECT * FROM stage_area_all_players_id where player like 'Mike Williams'
SELECT * FROM stage_area_all_players_id where player like 'DeAndre Hopkins'
SELECT * FROM stage_area_all_players_id where player like 'Anders Carlson'
SELECT * FROM stage_area_all_players_id where player like 'Spencer Shrader'
SELECT * FROM import_area_wr where player like 'Amari Cooper%'
SELECT * FROM import_area_RB where player like 'Cam Akers%'
SELECT * FROM import_area_wr where player like 'Davante Adams%'
SELECT * FROM import_area_wr where player like 'Marquez Valdes-Scantling%'
SELECT * FROM import_area_wr where player like 'Mike Williams%'
SELECT * FROM import_area_wr where player like 'DeAndre Hopkins%'
player	Team	Position
Diontae Johnson	BAL	WR
Spencer Shrader	NYJ	K
DELETE FROM stage_area_all_players_id where player like 'Spencer Shrader%'  AND TEAM = 'NYJ'
DELETE FROM stage_area_all_players_id where player like 'Spencer Shrader%'  AND TEAM = 'KC'
insert into stage_area_all_players_id
select HASHBYTES('SHA2_256', 'Spencer Shrader'+'K'+'IND') Id_Player, 'Spencer Shrader','K','NYJ'
insert into stage_area_all_players_id
select HASHBYTES('SHA2_256', 'Spencer Shrader'+'K'+'IND') Id_Player, 'Spencer Shrader','K','KC'

from stage_area_all_players_id 

right join 
(
select 
trim(substring(Player,1,len(player)-CHARINDEX ( '.', reverse(Player), 0 )-1)) player,
'WR' Position,
[Bolded Game Info] Team
from import_area_WR
WHERE player is not null
) import_area_WR
on (stage_area_all_players_id.id_player = HASHBYTES('SHA2_256', import_area_WR.Player+import_area_WR.Position+import_area_WR.Team))
left join stage_area_all_players_id stage_area_all_players_pos
on (stage_area_all_players_pos.Player = import_area_WR.Player and stage_area_all_players_pos.Position = import_area_WR.Position)
left join stage_area_all_players_id stage_area_all_players_team
on (stage_area_all_players_pos.Player = import_area_WR.Player and stage_area_all_players_pos.Team = import_area_WR.Team)
where stage_area_all_players_id.Id_Player is null and (stage_area_all_players_pos.Id_Player is not null or stage_area_all_players_team.Id_Player is not null) and stage_area_all_players_id.Id_Player = 0xFA2E2EDAD8466E128E418B071AEB2187D59DF29EBD8D96BE6FAF5CFD20EB8CED;
end;