DROP PROCEDURE IF EXISTS p_import_stage_pool_points;
CREATE PROCEDURE p_import_stage_pool_points AS
BEGIN
    -- Insert predefined scoring values for various categories into the 'stage_area_points' table
    INSERT INTO stage_area_points (
        [PassYds], [PassTD], [PassInt], [Pass2Pt], 
        [RushYds], [RushTD], [Rush2Pt], 
        [RecRec], [RecYds], [RecTD], [Rec2Pt], 
        [FumFL], [FumTD], 
        [XPMade], [XPMissed], [FGMade], [FGMissed], [50+], 
        [Sack], [Int], [Saf], [FR], [Blk], [TD], 
        [PA 0], [PA 6], [PA 13], [PA 20], [PA 34], [PA 35], 
        [TotYdsDST 100], [TotYdsDST 199], [TotYdsDST 299], 
        [TotYdsDST 399], [TotYdsDST 449], [TotYdsDST 499], 
        [TotYdsDST 549], [TotYdsDST 550]
    )
    SELECT 
        -- Passing stats
        0.04 AS [PassYds],  -- Points per passing yard
        4 AS [PassTD],      -- Points per passing touchdown
        -2 AS [PassInt],    -- Points lost per interception thrown
        2 AS [Pass2Pt],     -- Points per passing 2-point conversion

        -- Rushing stats
        0.1 AS [RushYds],   -- Points per rushing yard
        6 AS [RushTD],      -- Points per rushing touchdown
        2 AS [Rush2Pt],     -- Points per rushing 2-point conversion

        -- Receiving stats
        0.5 AS [RecRec],    -- Points per reception
        0.1 AS [RecYds],    -- Points per receiving yard
        6 AS [RecTD],       -- Points per receiving touchdown
        2 AS [Rec2Pt],      -- Points per receiving 2-point conversion

        -- Fumbles and touchdowns
        -2 AS [FumFL],      -- Points lost per fumble lost
        6 AS [FumTD],       -- Points per fumble return touchdown

        -- Kicking stats
        3 AS [XPMade],      -- Points per extra point made
        -1 AS [XPMissed],   -- Points lost per extra point missed
        1 AS [FGMade],      -- Points per field goal made
        -1 AS [FGMissed],   -- Points lost per field goal missed
        5 AS [50+],         -- Points for field goals made from 50+ yards

        -- Defensive stats
        1 AS [Sack],        -- Points per sack
        2 AS [Int],         -- Points per interception
        2 AS [Saf],         -- Points per safety
        2 AS [FR],          -- Points per fumble recovery
        2 AS [Blk],         -- Points per block (punt, kick, etc.)
        6 AS [TD],          -- Points per defensive/special teams touchdown

        -- Points allowed by defense
        5 AS [PA 0],        -- Points for allowing 0 points
        4 AS [PA 6],        -- Points for allowing 1-6 points
        3 AS [PA 13],       -- Points for allowing 7-13 points
        1 AS [PA 20],       -- Points for allowing 14-20 points
        -1 AS [PA 34],      -- Points lost for allowing 21-34 points
        -4 AS [PA 35],      -- Points lost for allowing 35+ points

        -- Total defensive/special teams yards allowed
        5 AS [TotYdsDST 100],    -- Points for allowing ? 100 total yards
        3 AS [TotYdsDST 199],    -- Points for allowing 101-199 total yards
        2 AS [TotYdsDST 299],    -- Points for allowing 200-299 total yards
        -1 AS [TotYdsDST 399],   -- Points lost for allowing 300-399 total yards
        -3 AS [TotYdsDST 449],   -- Points lost for allowing 400-449 total yards
        -5 AS [TotYdsDST 499],   -- Points lost for allowing 450-499 total yards
        -6 AS [TotYdsDST 549],   -- Points lost for allowing 500-549 total yards
        -7 AS [TotYdsDST 550]    -- Points lost for allowing ? 550 total yards
END;

DROP PROCEDURE IF EXISTS p_import_stage_pool_schedule;
CREATE PROCEDURE p_import_stage_pool_schedule AS
BEGIN
    -- Step 1: Clear the existing data in the import area table
    DELETE FROM [import_area_schedule];

    -- Step 2: Load the new schedule data from a CSV file
    BULK INSERT [import_area_schedule]
    FROM 'C:\Program Files\sleeper_nfl_project\venv\Scripts\game_schedule_2024.csv'
    WITH (
        FIELDTERMINATOR = ',',  -- Columns are separated by commas
        ROWTERMINATOR = '\n',   -- Rows are separated by newlines
        FIRSTROW = 2            -- Skip the header row
    );

    -- Step 3: Clear the existing data in the staging table
    DROP PROCEDURE IF EXISTS stage_area_schedule;

    -- Step 4: Insert data into the staging table with derived fields
    INSERT INTO stage_area_schedule
    SELECT * 
    FROM (
        -- Generate schedule for visiting teams
        SELECT 
            DENSE_RANK() OVER (ORDER BY game_date) AS week, -- Calculate the week number
            visitor AS team,                                -- Visiting team
            home AS opponent                                -- Home team as the opponent
        FROM (
            SELECT 
                -- Calculate game date adjusted to the start of the week (Monday)
                DATEADD(DAY, (7 - DATEPART(WEEKDAY, DATEADD(DAY, -1, CONVERT(DATE, SUBSTRING(date, 0, 11), 101)))) % 7, 
                DATEADD(DAY, -1, CONVERT(DATE, SUBSTRING(date, 0, 11), 101))) AS game_date,
                
                -- Normalize visitor team abbreviation
                CASE 
                    WHEN RIGHT(Visitor, 3) = UPPER(RIGHT(Visitor, 3)) AND RIGHT(Visitor, 3) COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]' 
                        THEN RIGHT(Visitor, 3)
                    WHEN RIGHT(Visitor, 2) = UPPER(RIGHT(Visitor, 2)) AND RIGHT(Visitor, 2) COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z]' 
                        THEN RIGHT(Visitor, 2)
                END AS visitor,
                
                -- Normalize home team abbreviation
                CASE 
                    WHEN RIGHT(Home, 3) = UPPER(RIGHT(Home, 3)) AND RIGHT(Home, 3) COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]' 
                        THEN RIGHT(Home, 3)
                    WHEN RIGHT(Home, 2) = UPPER(RIGHT(Home, 2)) AND RIGHT(Home, 2) COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z]' 
                        THEN RIGHT(Home, 2)
                END AS home
            FROM [import_area_schedule]
        ) AS normalized_schedule

        UNION

        -- Generate schedule for home teams
        SELECT 
            DENSE_RANK() OVER (ORDER BY game_date) AS week, -- Calculate the week number
            home AS team,                                   -- Home team
            visitor AS opponent                             -- Visiting team as the opponent
        FROM (
            SELECT 
                -- Calculate game date adjusted to the start of the week (Monday)
                DATEADD(DAY, (7 - DATEPART(WEEKDAY, DATEADD(DAY, -1, CONVERT(DATE, SUBSTRING(date, 0, 11), 101)))) % 7, 
                DATEADD(DAY, -1, CONVERT(DATE, SUBSTRING(date, 0, 11), 101))) AS game_date,
                
                -- Normalize visitor team abbreviation
                CASE 
                    WHEN RIGHT(Visitor, 3) = UPPER(RIGHT(Visitor, 3)) AND RIGHT(Visitor, 3) COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]' 
                        THEN RIGHT(Visitor, 3)
                    WHEN RIGHT(Visitor, 2) = UPPER(RIGHT(Visitor, 2)) AND RIGHT(Visitor, 2) COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z]' 
                        THEN RIGHT(Visitor, 2)
                END AS visitor,
                
                -- Normalize home team abbreviation
                CASE 
                    WHEN RIGHT(Home, 3) = UPPER(RIGHT(Home, 3)) AND RIGHT(Home, 3) COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z][A-Z]' 
                        THEN RIGHT(Home, 3)
                    WHEN RIGHT(Home, 2) = UPPER(RIGHT(Home, 2)) AND RIGHT(Home, 2) COLLATE Latin1_General_BIN LIKE '[A-Z][A-Z]' 
                        THEN RIGHT(Home, 2)
                END AS home
            FROM [import_area_schedule]
        ) AS normalized_schedule
    ) AS combined_schedule;
END;



-- Create the procedure
DROP PROCEDURE IF EXISTS p_import_area;
CREATE PROCEDURE p_import_area AS
BEGIN
    -- Define the base path for the CSV files
    DECLARE @base_path NVARCHAR(255) = 'C:\Program Files\sleeper_nfl_project\venv\Scripts\';

    -- Define a temporary table to store file details for BULK INSERT
    CREATE TABLE #file_imports (
        target_table NVARCHAR(255),
        file_name NVARCHAR(255)
    );

    -- Insert file and table mappings into the temporary table
    INSERT INTO #file_imports (target_table, file_name)
    VALUES 
        ('import_area_rosters', 'rosters_week_2024.csv'),
        ('import_area_sleeper_player', 'all_players_2024.csv'),
        ('import_area_TE', 'fantasy_stats_TE_2024_PPR.csv'),
        ('import_area_K', 'fantasy_stats_K_2024_PPR.csv'),
        ('import_area_DST', 'fantasy_stats_DST_2024_PPR.csv'),
        ('import_area_WR', 'fantasy_stats_WR_2024_PPR.csv'),
        ('import_area_RB', 'fantasy_stats_RB_2024_PPR.csv'),
        ('import_area_QB', 'fantasy_stats_QB_2024_PPR.csv');

    -- Loop through each file mapping and perform the delete and bulk insert operations
    DECLARE @target_table NVARCHAR(255);
    DECLARE @file_name NVARCHAR(255);
    DECLARE @full_file_path NVARCHAR(255);

    DECLARE cur CURSOR FOR 
        SELECT target_table, file_name
        FROM #file_imports;

    OPEN cur;
    FETCH NEXT FROM cur INTO @target_table, @file_name;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Construct the full file path
        SET @full_file_path = CONCAT(@base_path, @file_name);

        -- Delete existing records from the target table
        EXEC('DELETE FROM ' + @target_table);

        -- Perform the bulk insert operation
        EXEC('
            BULK INSERT ' + @target_table + '
            FROM ''' + @full_file_path + '''
            WITH (
                FIELDTERMINATOR = '','',
                ROWTERMINATOR = ''\n'',
                FIRSTROW = 2
            )
        ');

        FETCH NEXT FROM cur INTO @target_table, @file_name;
    END;

    CLOSE cur;
    DEALLOCATE cur;

    -- Drop the temporary table
    DROP TABLE #file_imports;
END;


DROP PROCEDURE IF EXISTS p_all_players_id_add;
-- Create the procedure
CREATE PROCEDURE p_all_players_id_add AS
BEGIN
    -- Clear the staging table before insertion
    DELETE FROM stage_area_all_players_id;

    -- Insert data for all player positions
    -- Use a common pattern for each position to reduce redundancy and improve clarity
    
    -- Insert Quarterbacks
    INSERT INTO stage_area_all_players_id
    SELECT 
        NULL AS Id_Player, 
        TRIM(SUBSTRING(Player, 1, LEN(Player) - CHARINDEX('.', REVERSE(Player), 0) - 1)) AS Player,
        'QB' AS Position, 
        [Bolded Game Info] AS Team
    FROM import_area_QB
    WHERE Player IS NOT NULL;

    -- Insert Wide Receivers
    INSERT INTO stage_area_all_players_id
    SELECT 
        NULL AS Id_Player, 
        CASE 
            WHEN Player LIKE 'Amon-Ra%' THEN 'Amon-Ra St. Brown' 
            ELSE TRIM(SUBSTRING(Player, 1, LEN(Player) - CHARINDEX('.', REVERSE(Player), 0) - 1)) 
        END AS Player,
        'WR' AS Position, 
        [Bolded Game Info] AS Team
    FROM import_area_WR
    WHERE Player IS NOT NULL;

    -- Insert Running Backs
    INSERT INTO stage_area_all_players_id
    SELECT 
        NULL AS Id_Player, 
        TRIM(SUBSTRING(Player, 1, LEN(Player) - CHARINDEX('.', REVERSE(Player), 0) - 1)) AS Player,
        'RB' AS Position, 
        [Bolded Game Info] AS Team
    FROM import_area_RB
    WHERE Player IS NOT NULL;

    -- Insert Tight Ends
    INSERT INTO stage_area_all_players_id
    SELECT 
        NULL AS Id_Player, 
        TRIM(SUBSTRING(Player, 1, LEN(Player) - CHARINDEX('.', REVERSE(Player), 0) - 1)) AS Player,
        'TE' AS Position, 
        [Bolded Game Info] AS Team
    FROM import_area_TE
    WHERE Player IS NOT NULL;

    -- Insert Kickers
    INSERT INTO stage_area_all_players_id
    SELECT 
        NULL AS Id_Player, 
        TRIM(SUBSTRING(Player, 1, LEN(Player) - CHARINDEX('.', REVERSE(Player), 0) - 1)) AS Player,
        'K' AS Position, 
        [Bolded Game Info] AS Team
    FROM import_area_K
    WHERE Player IS NOT NULL;

    -- Insert Defense/Special Teams
    INSERT INTO stage_area_all_players_id
    SELECT 
        NULL AS Id_Player, 
        TRIM(SUBSTRING(Player, 1, LEN(Player) - CHARINDEX('%' + [Bolded Game Info] + '%', Player, 0) - LEN([Bolded Game Info]))) AS Player,
        'DST' AS Position, 
        [Bolded Game Info] AS Team
    FROM import_area_DST
    WHERE Player IS NOT NULL;

		merge into stage_area_all_players_id using 
		(
		select a.player,a.position,
		CASE WHEN a.team = 'LAR' then 'LA' else a.team end team,
		import_area_sleeper_player.Player_id from
		(
		select player,position,team from(
		select player,position,CASE WHEN team = 'LA' then 'LAR' else team end team from stage_area_all_players_id
		) a 
		) a left join import_area_sleeper_player
		on (
		(a.player = import_area_sleeper_player.name and 
		a.position = import_area_sleeper_player.position and 
		a.team = import_area_sleeper_player.team
		) or
		(a.team = import_area_sleeper_player.player_id and 
		CASE WHEN a.position = 'DST' then 'DEF' else a.position end = import_area_sleeper_player.position and 
		a.team = import_area_sleeper_player.team
		)
		)
		where import_area_sleeper_player.player_id is not null
		) subq
		on (subq.player=stage_area_all_players_id.player and
		subq.team=stage_area_all_players_id.team and
		subq.position=stage_area_all_players_id.position
		)
		when matched then update set
		stage_area_all_players_id.id_player = subq.player_id;

		merge into stage_area_all_players_id using 
		(
		select a.player,a.position,
		CASE WHEN a.team = 'LAR' then 'LA' else a.team end team,
		import_area_footballdb_sleeper_fix.sleeper_Player_id from
		(
		select a.* from
		(
		select player,position,team from(
		select player,position,CASE WHEN team = 'LA' then 'LAR' else team end team from stage_area_all_players_id
		) a 
		) a left join import_area_sleeper_player
		on (
		(a.player = import_area_sleeper_player.name and 
		a.position = import_area_sleeper_player.position and 
		a.team = import_area_sleeper_player.team
		) or
		(a.team = import_area_sleeper_player.player_id and 
		CASE WHEN a.position = 'DST' then 'DEF' else a.position end = import_area_sleeper_player.position and 
		a.team = import_area_sleeper_player.team
		)
		)
		where import_area_sleeper_player.player_id is null
		) a left join import_area_footballdb_sleeper_fix 
		on (
		a.player = import_area_footballdb_sleeper_fix.footballdb_player and
		a.team = import_area_footballdb_sleeper_fix.footballdb_team and
		a.position = import_area_footballdb_sleeper_fix.footballdb_position
		)
		) subq
		on (subq.player=stage_area_all_players_id.player and
		subq.team=stage_area_all_players_id.team and
		subq.position=stage_area_all_players_id.position
		)
		when matched then update set
		stage_area_all_players_id.id_player = subq.sleeper_Player_id;


END;

-- Drop existing procedure if it exists
DROP PROCEDURE IF EXISTS p_correct_trades;

-- Create the procedure
CREATE PROCEDURE p_correct_trades (@p_week INT) AS
BEGIN
    -- Step 1: Update `stage_area_all_players_id` with trade corrections
    MERGE INTO stage_area_all_players_id AS target
    USING (
        SELECT 
            ISNULL(t.sleeper_player_id, f.sleeper_player_id) AS sleeper_player_id,
            ISNULL(t.footballdb_player, f.footballdb_player) AS footballdb_player,
            ISNULL(t.footballdb_position, f.footballdb_position) AS footballdb_position,
            ISNULL(t.team, f.footballdb_team) AS team,
            ISNULL(t.StartWeek, 1) AS StartWeek,
            ISNULL(t.EndWeek, NULL) AS EndWeek
        FROM (
            -- Combine trade data from `import_area_trades`
            SELECT 
                sleeper_player_id,
                footballdb_player,
                footballdb_position,
                arriving_team AS team,
                week AS StartWeek,
                LEAD(week) OVER (PARTITION BY sleeper_player_id ORDER BY week) AS EndWeek
            FROM import_area_trades
            UNION
            select sleeper_player_id,
                footballdb_player,
                footballdb_position,
                team,
                StartWeek,
                EndWeek from
			(SELECT 
                sleeper_player_id,
                footballdb_player,
                footballdb_position,
                leaving_team AS team,
				week,
                1 AS StartWeek,
                MIN(week) OVER (PARTITION BY sleeper_player_id ORDER BY week) AS EndWeek
            FROM import_area_trades) a
            WHERE week = EndWeek
        ) t
        FULL OUTER JOIN import_area_footballdb_sleeper_fix AS f
        ON f.sleeper_player_id = t.sleeper_player_id
        WHERE @p_week >= ISNULL(t.StartWeek, 1) AND @p_week < ISNULL(t.EndWeek, 19)
    ) AS source
    ON (target.id_player = source.sleeper_player_id 
        OR (target.player = source.footballdb_player 
            AND target.position = source.footballdb_position))
    WHEN MATCHED THEN 
        UPDATE SET 
            target.team = source.team,
            target.id_player = source.sleeper_player_id;

    -- Step 2: Update position-specific tables with corrected team info
    -- Common logic for updating position-specific tables
    DECLARE @positions TABLE (TableName NVARCHAR(50), Position NVARCHAR(10));
    INSERT INTO @positions VALUES
        ('import_area_TE', 'TE'),
        ('import_area_WR', 'WR'),
        ('import_area_RB', 'RB'),
        ('import_area_K', 'K'),
        ('import_area_QB', 'QB');

    DECLARE @tableName NVARCHAR(50), @position NVARCHAR(10);

    DECLARE table_cursor CURSOR FOR 
        SELECT TableName, Position FROM @positions;
    
    OPEN table_cursor;
    FETCH NEXT FROM table_cursor INTO @tableName, @position;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Dynamically update each position-specific table
        EXEC(
            'MERGE INTO ' + @tableName + ' AS target
            USING (
                SELECT * FROM stage_area_all_players_id WHERE position = ''' + @position + '''
            ) AS source
            ON (
                source.player = TRIM(SUBSTRING(target.player, 1, LEN(target.player) - CHARINDEX(''.'', REVERSE(target.player), 0) - 1))
            )
            WHEN MATCHED THEN 
                UPDATE SET target.[Bolded Game Info] = source.team;'
        );

        FETCH NEXT FROM table_cursor INTO @tableName, @position;
    END;

    CLOSE table_cursor;
    DEALLOCATE table_cursor;
END;

-- Drop existing procedure if it exists
DROP PROCEDURE IF EXISTS p_insert_area_all_by_week;

CREATE PROCEDURE p_insert_area_all_by_week AS
BEGIN
    -- Remove existing records from the target staging table
    DELETE FROM stage_area_all_positions_by_week;

    -- Common transformation logic for player names and game data
    WITH TransformedData AS (
        SELECT 
            Player = CASE 
                        WHEN Position = 'WR' AND TRIM(SUBSTRING(Player, 1, LEN(Player) - CHARINDEX('.', REVERSE(Player), 0) - 1)) LIKE 'Amon-Ra%' 
                        THEN 'Amon-Ra St. Brown'
                        WHEN Position <> 'DST' 
						THEN TRIM(SUBSTRING(Player, 1, LEN(Player) - CHARINDEX('.', REVERSE(Player), 0) - 1))
						ELSE TRIM(SUBSTRING(Player,1,LEN(Player)-CHARINDEX('%'+[Bolded Game Info]+'%', Player,0 )-LEN([Bolded Game Info])))
                     END,
            Position,
            Game,
            Team = [Bolded Game Info],
            Opponent = REPLACE(REPLACE(GAME, [Bolded Game Info], ''), '@', ''),
            [PassAtt], [PassCmp], [PassYds], [PassTD], [PassInt], [Pass2Pt],
            [RushAtt], [RushYds], [RushTD], [Rush2Pt], [RecRec], [RecYds], [RecTD], [Rec2Pt],
            [FumFL], [FumTD], [XPA], [XPM], [FGA], [FGM], [50+], [Sack], [Int], [Saf], 
            [FR], [Blk], [TD], [PA], [PassYdsDST], [RushYdsDST], [TotYdsDST]
        FROM (
            SELECT 
			Player,Game,[Bolded Game Info],
			[PassAtt],
			[PassCmp],
			[PassYds],
			[PassTD],
			[PassInt],
			[Pass2Pt],
			[RushAtt],
			[RushYds],
			[RushTD],
			[Rush2Pt],
			[RecRec],
			[RecYds],
			[RecTD],
			[Rec2Pt],
			[FumFL],
			[FumTD], 
			null [XPA],
			null [XPM],
			null [FGA],
			null [FGM],
			null [50+],
			null [Sack],
			null [Int],
			null [Saf],
			null [FR],
			null [Blk],
			null [TD],
			null [PA],
			null [PassYdsDST],
			null [RushYdsDST],
			null [TotYdsDST],
			'TE' AS Position FROM import_area_TE WHERE Player IS NOT NULL AND Game LIKE '%' + [Bolded Game Info] + '%'
            UNION ALL
            SELECT 
			Player,Game,[Bolded Game Info],
			[PassAtt],
			[PassCmp],
			[PassYds],
			[PassTD],
			[PassInt],
			[Pass2Pt],
			[RushAtt],
			[RushYds],
			[RushTD],
			[Rush2Pt],
			[RecRec],
			[RecYds],
			[RecTD],
			[Rec2Pt],
			[FumFL],
			[FumTD], 
			null [XPA],
			null [XPM],
			null [FGA],
			null [FGM],
			null [50+],
			null [Sack],
			null [Int],
			null [Saf],
			null [FR],
			null [Blk],
			null [TD],
			null [PA],
			null [PassYdsDST],
			null [RushYdsDST],
			null [TotYdsDST],
			'WR' AS Position FROM import_area_WR WHERE Player IS NOT NULL AND Game LIKE '%' + [Bolded Game Info] + '%'
            UNION ALL
            SELECT 
			Player,Game,[Bolded Game Info],
			[PassAtt],
			[PassCmp],
			[PassYds],
			[PassTD],
			[PassInt],
			[Pass2Pt],
			[RushAtt],
			[RushYds],
			[RushTD],
			[Rush2Pt],
			[RecRec],
			[RecYds],
			[RecTD],
			[Rec2Pt],
			[FumFL],	
			[FumTD], 
			null [XPA],
			null [XPM],
			null [FGA],
			null [FGM],
			null [50+],		
			null [Sack],
			null [Int],
			null [Saf],
			null [FR],
			null [Blk],
			null [TD],
			null [PA],
			null [PassYdsDST],
			null [RushYdsDST],
			null [TotYdsDST],		
			'RB' AS Position FROM import_area_RB WHERE Player IS NOT NULL AND Game LIKE '%' + [Bolded Game Info] + '%'
            UNION ALL
            SELECT 
			Player,Game,[Bolded Game Info],
			[PassAtt],
			[PassCmp],
			[PassYds],
			[PassTD],
			[PassInt],
			[Pass2Pt],
			[RushAtt],
			[RushYds],
			[RushTD],
			[Rush2Pt],
			[RecRec],
			[RecYds],
			[RecTD],
			[Rec2Pt],
			[FumFL],
			[FumTD], 
			null [XPA],
			null [XPM],
			null [FGA],
			null [FGM],
			null [50+],
			null [Sack],
			null [Int],
			null [Saf],
			null [FR],
			null [Blk],
			null [TD],
			null [PA],
			null [PassYdsDST],
			null [RushYdsDST],
			null [TotYdsDST],
			'QB' AS Position FROM import_area_QB WHERE Player IS NOT NULL AND Game LIKE '%' + [Bolded Game Info] + '%'
            UNION ALL
            SELECT 
			Player,Game,[Bolded Game Info],
			null [PassAtt],
			null [PassCmp],
			null [PassYds],
			null [PassTD],
			null [PassInt],
			null [Pass2Pt],
			null [RushAtt],
			null [RushYds],
			null [RushTD],
			null [Rush2Pt],
			null [RecRec],
			null [RecYds],
			null [RecTD],
			null [Rec2Pt],
			null [FumFL],
			null [FumTD], 
			[XPA],
			[XPM],
			[FGA],
			[FGM],
			[50+],
			null [Sack],
			null [Int],
			null [Saf],
			null [FR],
			null [Blk],
			null [TD],
			null [PA],
			null [PassYdsDST],
			null [RushYdsDST],
			null [TotYdsDST],
			'K' AS Position FROM import_area_K WHERE Player IS NOT NULL AND Game LIKE '%' + [Bolded Game Info] + '%'
            UNION ALL
            SELECT 
			Player,Game,[Bolded Game Info],
			null [PassAtt],
			null [PassCmp],
			null [PassYds],
			null [PassTD],
			null [PassInt],
			null [Pass2Pt],
			null [RushAtt],
			null [RushYds],
			null [RushTD],
			null [Rush2Pt],
			null [RecRec],
			null [RecYds],
			null [RecTD],
			null [Rec2Pt],
			null [FumFL],
			null [FumTD], 
			null [XPA],
			null [XPM],
			null [FGA],
			null [FGM],
			null [50+],
			[Sack],
			[Int],
			[Saf],
			[FR],
			[Blk],
			[TD],
			[PA],
			[PassYds] [PassYdsDST],
			[RushYds] [RushYdsDST],
			[TotYds] [TotYdsDST],
			'DST' AS Position FROM import_area_DST WHERE Player IS NOT NULL AND Game LIKE '%' + [Bolded Game Info] + '%'
        ) Data
    )

    -- Insert processed data into the staging table
    INSERT INTO stage_area_all_positions_by_week (
        Id_Player, Player, Position, Game, [Team], [Opponent],
        [PassAtt], [PassCmp], [PassYds], [PassTD], [PassInt], [Pass2Pt],
        [RushAtt], [RushYds], [RushTD], [Rush2Pt], [RecRec], [RecYds], 
        [RecTD], [Rec2Pt], [FumFL], [FumTD], [XPA], [XPM], [FGA], [FGM], 
        [50+], [Sack], [Int], [Saf], [FR], [Blk], [TD], [PA], 
        [PassYdsDST], [RushYdsDST], [TotYdsDST]
    )
    SELECT 
        sap.Id_Player, td.Player, td.Position, td.Game, td.Team, td.Opponent,
        td.[PassAtt], td.[PassCmp], td.[PassYds], td.[PassTD], td.[PassInt], td.[Pass2Pt],
        td.[RushAtt], td.[RushYds], td.[RushTD], td.[Rush2Pt], td.[RecRec], td.[RecYds], 
        td.[RecTD], td.[Rec2Pt], td.[FumFL], td.[FumTD], td.[XPA], td.[XPM], td.[FGA], 
        td.[FGM], td.[50+], td.[Sack], td.[Int], td.[Saf], td.[FR], td.[Blk], td.[TD], 
        td.[PA], td.[PassYdsDST], td.[RushYdsDST], td.[TotYdsDST]
    FROM 
        TransformedData td
    JOIN 
        stage_area_all_players_id sap
    ON 
        td.Player = sap.Player AND td.Position = sap.Position AND td.Team = sap.Team;

    -- Update points based on scoring rules
    MERGE INTO stage_area_all_positions_by_week AS tgt
    USING (
        SELECT 
            Id_Player,
            Points = 
                isnull(stage_area_all_positions_by_week.[PassYds],0)*isnull(stage_area_points.[PassYds],0) +
				isnull(stage_area_all_positions_by_week.[PassTD],0)*isnull(stage_area_points.[PassTD],0) +
				isnull(stage_area_all_positions_by_week.[PassInt],0)*isnull(stage_area_points.[PassInt],0) +
				isnull(stage_area_all_positions_by_week.[Pass2Pt],0)*isnull(stage_area_points.[Pass2Pt],0) +   
				isnull(stage_area_all_positions_by_week.[RushYds],0)*isnull(stage_area_points.[RushYds],0) +   
				isnull(stage_area_all_positions_by_week.[RushTD],0)*isnull(stage_area_points.[RushTD],0) +   
				isnull(stage_area_all_positions_by_week.[Rush2Pt],0)*isnull(stage_area_points.[Rush2Pt],0) +   
				isnull(stage_area_all_positions_by_week.[RecRec],0)*isnull(stage_area_points.[RecRec],0) +   
				isnull(stage_area_all_positions_by_week.[RecYds],0)*isnull(stage_area_points.[RecYds],0) +   
				isnull(stage_area_all_positions_by_week.[RecTD],0)*isnull(stage_area_points.[RecTD],0) +   
				isnull(stage_area_all_positions_by_week.[Rec2Pt],0)*isnull(stage_area_points.[Rec2Pt],0) +   
				isnull(stage_area_all_positions_by_week.[FumFL],0)*isnull(stage_area_points.[FumFL],0) +   
				isnull(stage_area_all_positions_by_week.[FumTD],0)*isnull(stage_area_points.[FumTD],0) +   
				(isnull(stage_area_all_positions_by_week.[XPA],0)-isnull(stage_area_all_positions_by_week.[XPM],0))*isnull(stage_area_points.[XPMissed],0) +   
				isnull(stage_area_all_positions_by_week.[XPM],0)*isnull(stage_area_points.[XPMade],0) +   
				(isnull(stage_area_all_positions_by_week.[FGA],0)-isnull(stage_area_all_positions_by_week.[FGM],0))*isnull(stage_area_points.[FGMissed],0) +   
				isnull(stage_area_all_positions_by_week.[FGM],0)*isnull(stage_area_points.[FGMade],0) +   
				isnull(stage_area_all_positions_by_week.[50+],0)*isnull(stage_area_points.[50+],0) +   
				isnull(stage_area_all_positions_by_week.[Sack],0)*isnull(stage_area_points.[Sack],0) +   
				isnull(stage_area_all_positions_by_week.[Int],0)*isnull(stage_area_points.[Int],0) +   
				isnull(stage_area_all_positions_by_week.[Saf],0)*isnull(stage_area_points.[Saf],0) +   
				isnull(stage_area_all_positions_by_week.[FR],0)*isnull(stage_area_points.[FR],0) +   
				isnull(stage_area_all_positions_by_week.[Blk],0)*isnull(stage_area_points.[Blk],0) +   
				isnull(stage_area_all_positions_by_week.[TD],0)*isnull(stage_area_points.[TD],0) +   
				CASE 
				WHEN stage_area_all_positions_by_week.[PA] = 0 then stage_area_points.[PA 0]
				WHEN stage_area_all_positions_by_week.[PA] between 1 and 6 then stage_area_points.[PA 6]
				WHEN stage_area_all_positions_by_week.[PA] between 7 and 13 then stage_area_points.[PA 13]
				WHEN stage_area_all_positions_by_week.[PA] between 14 and 20 then stage_area_points.[PA 20]
				WHEN stage_area_all_positions_by_week.[PA] between 28 and 34 then stage_area_points.[PA 34]
				WHEN stage_area_all_positions_by_week.[PA] >= 35 then stage_area_points.[PA 35]
				else 0 
				end +
				CASE 
				WHEN stage_area_all_positions_by_week.[TotYdsDST] < 100 then stage_area_points.[TotYdsDST 100]
				WHEN stage_area_all_positions_by_week.[TotYdsDST] between 100 and 199 then stage_area_points.[TotYdsDST 199]
				WHEN stage_area_all_positions_by_week.[TotYdsDST] between 200 and 299 then stage_area_points.[TotYdsDST 299]
				WHEN stage_area_all_positions_by_week.[TotYdsDST] between 350 and 399 then stage_area_points.[TotYdsDST 399]
				WHEN stage_area_all_positions_by_week.[TotYdsDST] between 400 and 449 then stage_area_points.[TotYdsDST 449]
				WHEN stage_area_all_positions_by_week.[TotYdsDST] between 450 and 499 then stage_area_points.[TotYdsDST 499] 
				WHEN stage_area_all_positions_by_week.[TotYdsDST] between 500 and 549 then stage_area_points.[TotYdsDST 549]
				WHEN stage_area_all_positions_by_week.[TotYdsDST] >= 550 then stage_area_points.[TotYdsDST 550]
				else 0
				end         
				FROM 
            stage_area_all_positions_by_week
        CROSS JOIN 
            stage_area_points
    ) src
    ON tgt.Id_Player = src.Id_Player
    WHEN MATCHED THEN
        UPDATE SET tgt.pts = src.Points;

    -- Refresh aggregated data by opponent
    DELETE FROM stage_area_all_positions_by_week_sum_by_opp;
    INSERT INTO stage_area_all_positions_by_week_sum_by_opp
    SELECT 
        Team, Opponent, Position,
		sum(Pts) Pts,
		sum(PassAtt) PassAtt,
		sum(PassCmp) PassCmp,
		sum(PassYds) PassYds,
		sum(PassTD) PassTD,
		sum(PassInt) PassInt,
		sum(Pass2Pt) Pass2Pt,
		sum(RushAtt) RushAtt,
		sum(RushYds) RushYds,
		sum(RushTD) RushTD,
		sum(Rush2Pt) Rush2Pt,
		sum(RecRec) RecRec,
		sum(RecYds) RecYds,
		sum(RecTD) RecTD,
		sum(Rec2Pt) Rec2Pt,
		sum(FumFL) FumFL,
		sum(FumTD) FumTD,
		sum(XPA) XPA,
		sum(XPM) XPM,
		sum(FGA) FGA,
		sum(FGM) FGM,
		sum([50+]) [50+],
		sum(Sack) Sack,
		sum(Int) Int,
		sum(Saf) Saf,
		sum(FR) FR,
		sum(Blk) Blk,
		sum(TD) TD,
		sum(PA) PA,
		sum(PassYdsDST) PassYdsDST,
		sum(RushYdsDST) RushYdsDST,
		sum(TotYdsDST) TotYdsDST
    FROM 
        stage_area_all_positions_by_week
    GROUP BY 
        Position, Team, Opponent;
END;


