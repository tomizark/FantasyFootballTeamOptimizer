USE [sleeper]
GO
/****** Object:  Table [dbo].[stage_area_all_players_id]    Script Date: 7.12.2024. 18:56:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[stage_area_all_players_id](
	[Id_Player] [nvarchar](10) NULL,
	[Player] [nvarchar](100) NULL,
	[Position] [nvarchar](3) NULL,
	[Team] [nvarchar](7) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[stage_area_all_positions_by_week]    Script Date: 7.12.2024. 18:56:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[stage_area_all_positions_by_week](
	[Id_Player] [nvarchar](10) NULL,
	[Player] [nvarchar](100) NULL,
	[Position] [nvarchar](3) NULL,
	[Game] [nvarchar](7) NULL,
	[Team] [nvarchar](7) NULL,
	[Opponent] [nvarchar](7) NULL,
	[Pts] [numeric](10, 2) NULL,
	[PassAtt] [int] NULL,
	[PassCmp] [int] NULL,
	[PassYds] [int] NULL,
	[PassTD] [int] NULL,
	[PassInt] [int] NULL,
	[Pass2Pt] [int] NULL,
	[RushAtt] [int] NULL,
	[RushYds] [int] NULL,
	[RushTD] [int] NULL,
	[Rush2Pt] [int] NULL,
	[RecRec] [int] NULL,
	[RecYds] [int] NULL,
	[RecTD] [int] NULL,
	[Rec2Pt] [int] NULL,
	[FumFL] [int] NULL,
	[FumTD] [int] NULL,
	[XPA] [int] NULL,
	[XPM] [int] NULL,
	[FGA] [int] NULL,
	[FGM] [int] NULL,
	[50+] [int] NULL,
	[Sack] [numeric](18, 0) NULL,
	[Int] [int] NULL,
	[Saf] [int] NULL,
	[FR] [int] NULL,
	[Blk] [int] NULL,
	[TD] [int] NULL,
	[PA] [int] NULL,
	[PassYdsDST] [int] NULL,
	[RushYdsDST] [int] NULL,
	[TotYdsDST] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[stage_area_all_positions_by_week_sum_by_opp]    Script Date: 7.12.2024. 18:56:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[stage_area_all_positions_by_week_sum_by_opp](
	[team] [nvarchar](7) NULL,
	[opponent] [nvarchar](7) NULL,
	[position] [nvarchar](3) NULL,
	[Pts] [numeric](38, 2) NULL,
	[PassAtt] [int] NULL,
	[PassCmp] [int] NULL,
	[PassYds] [int] NULL,
	[PassTD] [int] NULL,
	[PassInt] [int] NULL,
	[Pass2Pt] [int] NULL,
	[RushAtt] [int] NULL,
	[RushYds] [int] NULL,
	[RushTD] [int] NULL,
	[Rush2Pt] [int] NULL,
	[RecRec] [int] NULL,
	[RecYds] [int] NULL,
	[RecTD] [int] NULL,
	[Rec2Pt] [int] NULL,
	[FumFL] [int] NULL,
	[FumTD] [int] NULL,
	[XPA] [int] NULL,
	[XPM] [int] NULL,
	[FGA] [int] NULL,
	[FGM] [int] NULL,
	[50+] [int] NULL,
	[Sack] [numeric](38, 0) NULL,
	[Int] [int] NULL,
	[Saf] [int] NULL,
	[FR] [int] NULL,
	[Blk] [int] NULL,
	[TD] [int] NULL,
	[PA] [int] NULL,
	[PassYdsDST] [int] NULL,
	[RushYdsDST] [int] NULL,
	[TotYdsDST] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[stage_area_points]    Script Date: 7.12.2024. 18:56:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[stage_area_points](
	[PassYds] [numeric](10, 2) NULL,
	[PassTD] [int] NULL,
	[PassInt] [int] NULL,
	[Pass2Pt] [int] NULL,
	[RushYds] [numeric](10, 2) NULL,
	[RushTD] [int] NULL,
	[Rush2Pt] [int] NULL,
	[RecRec] [numeric](10, 2) NULL,
	[RecYds] [numeric](10, 2) NULL,
	[RecTD] [int] NULL,
	[Rec2Pt] [int] NULL,
	[FumFL] [int] NULL,
	[FumTD] [int] NULL,
	[XPMade] [int] NULL,
	[XPMissed] [int] NULL,
	[FGMade] [int] NULL,
	[FGMissed] [int] NULL,
	[50+] [int] NULL,
	[Sack] [int] NULL,
	[Int] [int] NULL,
	[Saf] [int] NULL,
	[FR] [int] NULL,
	[Blk] [int] NULL,
	[TD] [int] NULL,
	[PA 0] [int] NULL,
	[PA 6] [int] NULL,
	[PA 13] [int] NULL,
	[PA 20] [int] NULL,
	[PA 34] [int] NULL,
	[PA 35] [int] NULL,
	[TotYdsDST 100] [int] NULL,
	[TotYdsDST 199] [int] NULL,
	[TotYdsDST 299] [int] NULL,
	[TotYdsDST 399] [int] NULL,
	[TotYdsDST 449] [int] NULL,
	[TotYdsDST 499] [int] NULL,
	[TotYdsDST 549] [int] NULL,
	[TotYdsDST 550] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[stage_area_schedule]    Script Date: 7.12.2024. 18:56:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[stage_area_schedule](
	[week] [bigint] NULL,
	[team] [nvarchar](3) NULL,
	[opponent] [nvarchar](3) NULL
) ON [PRIMARY]
GO
