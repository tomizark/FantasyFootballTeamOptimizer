import requests
import csv
import argparse
import os

def fetch_weekly_rosters(week):
    # Hardcoded league ID
    league_id = "1124846695318839296"  # Replace with your Sleeper league ID

    # Fetch matchups for the given league and week
    matchup_url = f"https://api.sleeper.app/v1/league/{league_id}/matchups/{week}"
    response = requests.get(matchup_url)

    fixed_save_dir = r"C:\Program Files\sleeper_nfl_project\venv\Scripts\History"

    if response.status_code == 200:
        matchups = response.json()

        # Fetch player details
        player_url = "https://api.sleeper.app/v1/players/nfl"
        player_response = requests.get(player_url)
        players = player_response.json() if player_response.status_code == 200 else {}

        # Define output file names
        output_file_1 = f"rosters_week_2024.csv"
        output_file_2 = f"rosters_week_{week}_2024.csv"

        # Save rosters to the first CSV file
        with open(output_file_1, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Roster ID', 'Player ID', 'Player Name', 'Team', 'Position'])

            for matchup in matchups:
                roster_id = matchup.get('roster_id', 'N/A')
                player_ids = matchup.get('players', [])

                for player_id in player_ids:
                    player_data = players.get(player_id, {})
                    player_name = player_data.get('full_name', 'Unknown Player')
                    player_team = player_data.get('team', 'N/A')
                    player_position = player_data.get('position', 'N/A')

                    writer.writerow([roster_id, player_id, player_name, player_team, player_position])

        print(f"Rosters for week {week} have been saved to {output_file_1}.")

        # Ensure the fixed directory exists
        if not os.path.exists(fixed_save_dir):
            os.makedirs(fixed_save_dir)

        # File 2: Save to the fixed directory
        output_path = os.path.join(fixed_save_dir, output_file_2)

        # Check if file exists and delete if it does
        if os.path.exists(output_path):
            os.remove(output_path)
            print(f"Existing file {output_path} has been deleted.")

        with open(output_path, mode='w', newline='') as file2:
            writer = csv.writer(file2)
            writer.writerow(['Roster ID', 'Player ID', 'Player Name', 'Team', 'Position'])

            for matchup in matchups:
                roster_id = matchup.get('roster_id', 'N/A')
                player_ids = matchup.get('players', [])

                for player_id in player_ids:
                    player_data = players.get(player_id, {})
                    player_name = player_data.get('full_name', 'Unknown Player')
                    player_team = player_data.get('team', 'N/A')
                    player_position = player_data.get('position', 'N/A')

                    writer.writerow([roster_id, player_id, player_name, player_team, player_position])

        print(f"Rosters for week {week} have been saved to {output_path}.")
    else:
        print(f"Failed to retrieve player data. Status code: {response.status_code}")
        print(f"Response: {response.text}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fetch rosters for a specific week of the Sleeper fantasy league.")
    parser.add_argument('week', type=int, help='The week number to fetch rosters for (e.g., 1, 2, 3, etc.).')

    args = parser.parse_args()

    # Call the function with the input week
    fetch_weekly_rosters(args.week)
