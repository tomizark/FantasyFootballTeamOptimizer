-- Drop the procedure if it exists
DROP PROCEDURE IF EXISTS p_insert_pool_by_week;
GO

-- Create the procedure
CREATE PROCEDURE p_insert_pool_by_week (@p_week INT) 
AS
BEGIN
    -- Remove old data for the given week from pool tables
    DELETE FROM pool_area_all_positions_by_week WHERE week = @p_week;
    DELETE FROM pool_area_all_players_id WHERE week = @p_week;
    DELETE FROM pool_area_all_positions_by_week_sum_by_opp WHERE week = @p_week;
    DELETE FROM pool_area_all_positions_last_3_week WHERE week = @p_week;
    DELETE FROM pool_area_all_teams_last_3_week WHERE week = @p_week;
    DELETE FROM pool_area_sleeper_player WHERE week = @p_week;
    DELETE FROM pool_area_rosters WHERE week = @p_week;

    -- Insert current week's data into pool tables
    INSERT INTO pool_area_all_positions_by_week 
    SELECT @p_week AS week, * FROM stage_area_all_positions_by_week;

    INSERT INTO pool_area_all_players_id 
    SELECT @p_week AS week, * FROM stage_area_all_players_id;

    INSERT INTO pool_area_all_positions_by_week_sum_by_opp 
    SELECT @p_week AS week, * FROM stage_area_all_positions_by_week_sum_by_opp;

    -- Maintain historical records of players not in the current week's data
    INSERT INTO pool_area_all_positions_by_week (week, id_player, player, position, game, team, opponent)
    SELECT 
        @p_week AS week,
        a.id_player, 
        a.player, 
        a.position, 
        game.game, 
        a.team, 
        game.opponent
    FROM (
        SELECT 
            p.week, 
            p.id_player, 
            p.player, 
            p.position, 
            p.team 
        FROM pool_area_all_positions_by_week p
        INNER JOIN (
            SELECT 
                id_player, 
                MAX(week) AS max_week 
            FROM pool_area_all_positions_by_week 
            WHERE id_player NOT IN (
                SELECT DISTINCT id_player FROM stage_area_all_positions_by_week
            )
            GROUP BY id_player
        ) max_week 
        ON p.id_player = max_week.id_player 
           AND p.week = max_week.max_week
        WHERE p.player IS NOT NULL
    ) a
    LEFT JOIN (
        SELECT DISTINCT team, game, opponent 
        FROM pool_area_all_positions_by_week 
        WHERE week = @p_week
    ) game
    ON a.team = game.team;

    -- Maintain last 3 weeks' data for positions
    INSERT INTO pool_area_all_positions_last_3_week (week, id_player, player, week_prev_3)
    SELECT 
        @p_week AS week,
		id_player, 
        player, 
		week week_prev_3
		from
        (
		SELECT
		week,
		id_player, 
        player, 
        week_rank,
        MAX(week_rank) over (partition by id_player,player) max_week_rank
        FROM 
	    (
         SELECT 
            week, 
            id_player, 
            player, 
            ROW_NUMBER() OVER (PARTITION BY id_player, player ORDER BY week DESC) week_rank
			FROM
			(
			SELECT
			DISTINCT week,id_player,player
			FROM pool_area_all_positions_by_week
			WHERE week <= @p_week AND pts IS NOT NULL
			) pool_area_all_positions_by_week
		) max_week_rank
		where week_rank <= 3
    ) ranked
    WHERE  week_rank = max_week_rank;

    -- Maintain historical opponent data
    INSERT INTO pool_area_all_positions_by_week_sum_by_opp (week, team, opponent, position)
    SELECT 
        @p_week AS week,
        a.team, 
        game.opponent, 
        a.position
    FROM (
        SELECT 
            p.week, 
            p.team, 
            p.position
        FROM pool_area_all_positions_by_week_sum_by_opp p
        INNER JOIN (
            SELECT 
                team, 
                position, 
                MAX(week) AS max_week 
            FROM pool_area_all_positions_by_week_sum_by_opp 
            WHERE team + position NOT IN (
                SELECT DISTINCT team + position FROM stage_area_all_positions_by_week_sum_by_opp
            )
            GROUP BY team, position
        ) max_week
        ON p.team = max_week.team 
           AND p.position = max_week.position 
           AND p.week = max_week.max_week
        WHERE p.team IS NOT NULL AND p.position IS NOT NULL
    ) a
    LEFT JOIN (
        SELECT DISTINCT team, game, opponent 
        FROM pool_area_all_positions_by_week 
        WHERE week = @p_week
    ) game
    ON a.team = game.team;

    -- Maintain last 3 weeks' data for teams
    INSERT INTO pool_area_all_teams_last_3_week (week, team, week_prev_3)
    SELECT 
        @p_week AS week,
		team,
		week week_prev_3
		from
        (
		SELECT
		week,
		team,
        week_rank,
        MAX(week_rank) over (partition by team) max_week_rank
        FROM 
	    (
         SELECT 
            week, 
            team, 
            ROW_NUMBER() OVER (PARTITION BY team ORDER BY week DESC) week_rank
			FROM
			(
			SELECT
			DISTINCT week,team
			FROM pool_area_all_positions_by_week
			WHERE week <= @p_week AND pts IS NOT NULL
			) pool_area_all_positions_by_week
		) max_week_rank
		where week_rank <= 3
    ) ranked
    WHERE week_rank = max_week_rank;

    -- Insert sleeper player data
    INSERT INTO pool_area_sleeper_player 
    SELECT @p_week AS week, * FROM import_area_sleeper_player;

    -- Insert rosters data
    INSERT INTO pool_area_rosters 
    SELECT @p_week AS week, * FROM import_area_rosters;
END;
GO
