import requests
import argparse
import os
import csv

def fetch_and_save_players(week):
    # URL to fetch player data (no need for season-specific endpoint)
    url = "https://api.sleeper.app/v1/players/nfl"

    # Fixed directory for the second file
    fixed_save_dir = r"C:\Program Files\sleeper_nfl_project\venv\Scripts\History"

    # Make the request to the Sleeper API
    response = requests.get(url)

    if response.status_code == 200:
        players = response.json()

        # Define filenames
        csv_filename_1 = 'all_players_2024.csv'
        csv_filename_2 = f'all_players_2024_week_{week}.csv'		

        # File 1: Save to current directory
        with open(csv_filename_1, mode='w', newline='') as file1:
            writer = csv.writer(file1)
            writer.writerow(['Player ID', 'Name', 'Team', 'Position'])  # Header row

            for player_id, player_data in players.items():
                player_name = player_data.get('full_name', 'N/A')
                player_team = player_data.get('team', 'N/A')
                player_position = player_data.get('position', 'N/A')
                writer.writerow([player_id, player_name, player_team, player_position])

        print(f"Player data has been saved to {csv_filename_1}")

        # Ensure the fixed directory exists
        if not os.path.exists(fixed_save_dir):
            os.makedirs(fixed_save_dir)

        # File 2: Save to fixed directory
        output_path = os.path.join(fixed_save_dir, csv_filename_2)

        # Check if file exists and delete if it does
        if os.path.exists(output_path):
            os.remove(output_path)
            print(f"Existing file {output_path} has been deleted.")

        with open(output_path, mode='w', newline='') as file2:
            writer = csv.writer(file2)
            writer.writerow(['Player ID', 'Name', 'Team', 'Position'])  # Header row

            for player_id, player_data in players.items():
                player_name = player_data.get('full_name', 'N/A')
                player_team = player_data.get('team', 'N/A')
                player_position = player_data.get('position', 'N/A')
                writer.writerow([player_id, player_name, player_team, player_position])

        print(f"Player data has been saved to {output_path}")

    else:
        print(f"Failed to retrieve player data. Status code: {response.status_code}")
        print(f"Response: {response.text}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fetch and save player data for a specific week.")
    parser.add_argument('week', type=int, help='The week number (e.g., 1, 2, 3, etc.)')

    args = parser.parse_args()

    # Call the function with the arguments passed from the command line
    fetch_and_save_players(args.week)
