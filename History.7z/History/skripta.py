import os
import re

# Define source path
destination_base_path = r"C:\Users\tomis\Downloads\History"

# Loop through each week folder (week_1 to week_12)
for x in range(1, 13):
    week_folder = os.path.join(destination_base_path, f"week_{x}")
    
    # Check if the folder exists
    if os.path.exists(week_folder):
        # Loop through each file in the folder
        for filename in os.listdir(week_folder):
            # Check if the filename ends with ".csv" (in case it lost the extension earlier)
            if not filename.endswith('.csv'):
                # Check if the file matches the pattern, indicating it needs to have ".csv" added
                match = re.match(r"fantasy_stats_(\w+)_2024_PPR", filename)
                if match:
                    # Construct the new filename by adding ".csv" at the end
                    new_filename = f"{filename}.csv"
                    
                    # Define the full paths for the old and new filenames
                    old_file_path = os.path.join(week_folder, filename)
                    new_file_path = os.path.join(week_folder, new_filename)
                    
                    # Rename the file (add the .csv extension)
                    os.rename(old_file_path, new_file_path)
                    print(f"Renamed: {old_file_path} -> {new_file_path}")
