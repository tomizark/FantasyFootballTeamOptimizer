import pandas as pd
import os
import argparse
from sleeper_wrapper import League

def fetch_all_team_rosters(league_id):
    """Fetch all team rosters from the Sleeper API using the wrapper."""
    league = League(league_id)  # Create a League object using the provided league ID
    rosters = league.get_rosters()  # Fetch all rosters
    return rosters

def save_combined_roster(rosters, output_dir, league_id):
    """Save combined rosters to a CSV file."""
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    all_players = []  # List to hold all player data

    if isinstance(rosters, dict):  # Check if rosters is a dictionary
        print("Fetched rosters successfully.")
        
        for team_id, roster in rosters.items():
            for player_id in roster['players']:  # Access player IDs from the roster
                player_info = {
                    'player_id': player_id,
                    'team_id': team_id,
                    **roster['players'][player_id]  # Add other player details if available
                }
                all_players.append(player_info)

        # Check how many players were collected
        print(f"Total players collected: {len(all_players)}")

        # Create a DataFrame from the list of players if any were collected
        if all_players:
            combined_roster_df = pd.DataFrame(all_players)

            # Create the output file path for the combined roster
            output_file_path = os.path.join(output_dir, f'combined_roster_league_{league_id}.csv')
            
            # Save the combined DataFrame to a CSV file
            try:
                combined_roster_df.to_csv(output_file_path, index=False)
                print(f"Combined roster saved to {output_file_path}")
            except Exception as e:
                print(f"Failed to save combined CSV: {e}")
        else:
            print("No player data available to save.")
    else:
        print("Unexpected data format for rosters:", type(rosters))

def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(description='Fetch all team rosters from Sleeper API and save as a single CSV')
    parser.add_argument('league_id', type=str, help='League ID to fetch the rosters from')

    # Parse the command-line arguments
    args = parser.parse_args()

    league_id = args.league_id
    output_dir = "C:\\Program Files\\sleeper_nfl_project\\venv\\Scripts"  # Specify your output directory

    rosters = fetch_all_team_rosters(league_id)

    if rosters:
        save_combined_roster(rosters, output_dir, league_id)
    else:
        print("No roster data available.")

if __name__ == '__main__':
    main()
