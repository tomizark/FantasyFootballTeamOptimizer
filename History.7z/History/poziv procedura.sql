--delete from stage_area_all_players_id;
--insert into stage_area_all_players_id
--select distinct id_player, player, position, team from pool_area_all_players_id
--import
exec p_import_area;
--stage
exec p_all_players_id_add;
--correct trades
exec p_correct_trades @p_week = 13;
--check
select * from stage_area_all_players_id where id_player is null
--insert stage
exec p_insert_area_all_by_week;
--insert pool
exec p_insert_pool_by_week @p_week = 13;
--insert analitics
exec p_insert_analitics_by_cur_week_for_futu @p_week = 13;

exec p_insert_analitics_by_cur_week_for_futu @p_week = 1;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 2;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 3;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 4;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 5;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 6;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 7;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 8;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 9;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 10;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 11;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 12;
exec p_insert_analitics_by_cur_week_for_futu @p_week = 13;






select * from import_area_WR where player like 'Amari%'
select * from stage_area_all_players_id where  player = 'Amari Cooper' order by 1
MERGE INTO import_area_WR USING
(select * from stage_area_all_players_id where position = 'WR') subq
ON (subq.player= trim(substring(import_area_WR.player,1,len(import_area_WR.player)-CHARINDEX ( '.', reverse(import_area_WR.player), 0 )-1)))
when matched then update
set import_area_WR.[Bolded Game Info] = subq.team;

select * from pool_area_all_players_id where  player = 'Amari Cooper' order by 1
select * from import_area_sleeper_player where PLAYER_ID = '10218'
NAME LIKE '%Chosen' team = 'MIA' and position = 'WR'
select * from import_area_trades 
INSERT INTO import_area_trades select player_id,name,name,team,'MIA','WR',2 from import_area_sleeper_player where NAME LIKE '%Chosen'
select * from import_area_trades
update import_area_trades set week = 7 where sleeper_player = 'Amari Cooper'

